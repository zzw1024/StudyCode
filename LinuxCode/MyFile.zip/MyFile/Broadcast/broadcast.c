/*************************************************************************
    > File Name: broadcast.c
    > Author: zzw
    > Mail: 819342493@qq.com 
    > Created Time: Wed 03 Apr 2019 10:03:24 PM CST
 ************************************************************************/

#include<stdio.h>
#include<unistd.h>
#include <sys/types.h>          /* See NOTES */
#include <sys/socket.h>
#include <stdlib.h>
#include <string.h>
#include <arpa/inet.h>
#include <stdarg.h>
#include <sys/stat.h>

int main(int agc, char *agv[])
{
	//创建套接字
	int lfd = socket(AF_INET, SOCK_DGRAM, 0);
	if(lfd == -1)
	{
		perror("socket error!\n");
		exit(1);
	}

	//绑定服务器IP
	struct sockaddr_in serv;
	memset(&serv, 0, sizeof(serv));
	serv.sin_family = AF_INET;
	serv.sin_addr.s_addr = htonl(INADDR_ANY);
	serv.sin_port = htons(8787);

	// 绑定
	//int ret;// = bind(lfd, (struct sockaddr*)&serv, sizeof(serv));
	int rett = bind(lfd, (struct sockaddr*)&serv, sizeof(serv));
	if(rett == -1)
	{
		perror("bind error!\n");
		exit(1);
	}

	//初始化客户端信息
	struct sockaddr_in client;
	memset(&client, 0, sizeof(client));
	client.sin_family = AF_INET;
	client.sin_port = htons(6767);//由于使用本地机测试，故不能使用同一端口

	//使用广播给客户端发送信息
	inet_pton(AF_INET,"192.168.233.255",&client.sin_addr.s_addr);

	//开通广播权限
	int flag  = 1;
	setsockopt(lfd, SOL_SOCKET, SO_BROADCAST, &flag, sizeof(flag));

	//通信
	while(1)
	{
		//一直给客户端发送数据
		static int num = 0;
		char buf[1024] = {0};
		sprintf(buf, "hello world %d\n", num++);
		
		int ret = sendto(lfd, buf, strlen(buf)+1, 0, (struct sockaddr*)&client, sizeof(client));
		if(ret == -1)
		{
			perror("sendto error!\n");
			exit(1);
		}

		printf("the serve send message is: %s\n", buf);

		sleep(1);
	}
	close(lfd);
	
	return 0;
}
