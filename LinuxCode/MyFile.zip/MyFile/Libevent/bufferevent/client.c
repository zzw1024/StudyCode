/*************************************************************************
  > File Name: write_fifo.c
  > Author: zzw
  > Mail: 819342493@qq.com 
  > Created Time: Sat 13 Apr 2019 10:38:07 AM CST
 ************************************************************************/

#include<stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <string.h>
#include <event2/event.h>
#include <event2/bufferevent.h>

void read_cb(struct bufferevent *bev, void *arg)
{
	char buff[1024] = {0};
	bufferevent_read(bev, buff, sizeof(buff));
	printf("Server say: %s\n",buff);
}

void write_cb(struct bufferevent *bev, void *arg)
{
	printf("I am write_cb function...\n");
}

void event_cb(struct bufferevent *bev, short events, void *arg)
{
	if(events & BEV_EVENT_EOF)
		printf("connection closed!\n");
	else if(events & BEV_EVENT_ERROR)
		printf("some other error!\n");
	else if(events & BEV_EVENT_CONNECTED)
	{
		printf("成功连接到服务器!\n");
		return ;
	}

	bufferevent_free(bev);
	printf("free bufferevent...\n");	
}

void send_cb(evutil_socket_t fd, short what, void *arg)
{
	char buff[1024] = {0};
	struct bufferevent* bev = (struct bufferevent*)arg;
	printf("请输入要发送的数:\n");
	read(fd, buff, sizeof(buff));
	bufferevent_write(bev, buff, strlen(buff)+1);
}


int main()
{
	struct event_base* base;
	base = event_base_new();
	
	//创建套接字
	struct bufferevent* bev;
	bev = bufferevent_socket_new(base, -1, BEV_OPT_CLOSE_ON_FREE);

	//连接服务器
	struct sockaddr_in serv;
	memset(&serv, 0, sizeof(serv));

	serv.sin_family = AF_INET;
	serv.sin_port = htons(9898);
	
	evutil_inet_pton(AF_INET, "127.0.0.1", &serv.sin_addr.s_addr);
	bufferevent_socket_connect(bev, (struct sockaddr*)&serv, sizeof(serv));

	//设置回调//读写缓冲区操作
	bufferevent_setcb(bev, read_cb, write_cb, event_cb, NULL);

	//启用缓冲区
	bufferevent_enable(bev, EV_READ|EV_PERSIST);

	//创建一个事件                     
	struct event* ev = event_new(base, STDIN_FILENO, EV_READ | EV_PERSIST, send_cb, bev);

	event_add(ev, NULL);
	//循环
	event_base_dispatch(base);
	//释放
	event_base_free(base);

	return 0;	
}
