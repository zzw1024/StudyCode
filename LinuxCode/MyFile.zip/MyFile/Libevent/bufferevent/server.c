/*************************************************************************
  > File Name: write_fifo.c
  > Author: zzw
  > Mail: 819342493@qq.com 
  > Created Time: Sat 13 Apr 2019 10:38:07 AM CST
 ************************************************************************/

#include<stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <string.h>
#include <event2/event.h>
#include <event2/listener.h>
#include <event2/bufferevent.h>

void read_cb(struct bufferevent *bev, void *arg)
{
	char buff[1024] = {0};
	bufferevent_read(bev, buff, sizeof(buff));
	char *p = "我已经收到你的数据！";
	printf("client say: %s\n",p);

	//发送数据给客户端//其实这一段是没什么用的
	bufferevent_write(bev, p, strlen(p)+1);
	printf("======== send buf: %s\n",p);
}

void write_cb(struct bufferevent *bev, void *arg)
{
	printf("I am write_cb function...\n");
}

void event_cb(struct bufferevent *bev, short events, void *arg)
{
	if(events & BEV_EVENT_EOF)
		printf("connection closed!\n");
	else if(events & BEV_EVENT_ERROR)
		printf("some other error!\n");

	bufferevent_free(bev);
	printf("bufferevent free !...\n");	
}

void cb_listener(struct evconnlistener* listener, evutil_socket_t lfd, struct sockaddr *addr,
				 int len, void *ptr)
{
	printf("connect new client!\n");

	struct event_base* base = (struct event_base*)ptr;
	struct bufferevent *bev;
	bev = bufferevent_socket_new(base, lfd, BEV_OPT_CLOSE_ON_FREE);

	bufferevent_setcb(bev, read_cb, write_cb, event_cb, NULL);
	bufferevent_enable(bev, EV_READ);
}

void send_cb(evutil_socket_t fd, short what, void *arg)
{
	char buff[1024] = {0};
	struct bufferevent* bev = (struct bufferevent*)arg;
	printf("请输入要发送的数:\n");
	read(fd, buff, sizeof(buff));
	bufferevent_write(bev, buff, strlen(buff)+1);
}


int main()
{

	struct event_base* base;
	base = event_base_new();
	
	//连接服务器
	struct sockaddr_in serv;
	memset(&serv, 0, sizeof(serv));

	serv.sin_family = AF_INET;
	serv.sin_port = htons(9898);
	serv.sin_addr.s_addr = htonl(INADDR_ANY);

	//建立监听
	struct evconnlistener* listener;
	listener = evconnlistener_new_bind(base, cb_listener, base, 
									   LEV_OPT_CLOSE_ON_FREE | LEV_OPT_REUSEABLE,
									   36,(struct sockaddr*)&serv, sizeof(serv));
	//循环
	event_base_dispatch(base);
	evconnlistener_free(listener);
	//释放
	event_base_free(base);

	return 0;	
}
