/*************************************************************************
    > File Name: main.c
    > Author: zzw
    > Mail: 819342493@qq.com 
    > Created Time: Sun 21 Apr 2019 07:26:50 PM CST
 ************************************************************************/

#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include "epoll_server.h"

int main(int argc, const char* argv[])
{
	if(argc < 3)//传参端口  温江路径
	{
		printf("please input the port and file path!\n");
		exit(1);
	}
	int port = atoi(argv[1]);//获取端口号
	int ret  =chdir(argv[2]);//文件路径
	if(ret == -1)
	{
		perror("chdir error!\n");
		exit(1);
	}

	//启动epoll模型
	epoll_run(port);

	return 0;
}
