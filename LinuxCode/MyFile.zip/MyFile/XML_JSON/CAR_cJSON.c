/*************************************************************************
    > File Name: CAR_cJSON.c
    > Author: zzw
    > Mail: 819342493@qq.com 
    > Created Time: Mon 15 Apr 2019 09:00:38 PM CST
 ************************************************************************/

#include<stdio.h>
#include<string.h>
#include"cJSON.h"


int main()
{
	//创建对象
	cJSON* rootObj = cJSON_CreateObject();

	//创建子对象
	cJSON* subObj = cJSON_CreateObject();

	//向子对象中添加信息
	cJSON_AddItemToObject(subObj, "factor", cJSON_CreateString("一汽大众"));
	cJSON_AddItemToObject(subObj, "last", cJSON_CreateNumber(31));
	cJSON_AddItemToObject(subObj, "price", cJSON_CreateNumber(83));
	cJSON_AddItemToObject(subObj, "sell", cJSON_CreateNumber(49));
	cJSON_AddItemToObject(subObj, "sum", cJSON_CreateNumber(80));

	//创建数组
	cJSON* array = cJSON_CreateArray();
	//向数组中添加信息
	cJSON_AddItemToArray(array, cJSON_CreateNumber(124));
	cJSON_AddItemToArray(array, cJSON_CreateString("hello, world"));
	cJSON_AddItemToArray(array, cJSON_CreateBool(0));

	//将数组添加进行子对象中
	cJSON_AddItemToObject(subObj, "other", array);
	//将子对象添加进对象中
	cJSON_AddItemToObject(rootObj, "奔驰", subObj);


	//数据格式化
	char*data = cJSON_Print(rootObj);
	//写入文件中
	FILE* fp = fopen("CAR.json", "w");
	fwrite(data, 1, strlen(data), fp);
	fclose(fp);
	cJSON_Delete(rootObj);


}
