/*************************************************************************
    > File Name: Car_parsel.c
    > Author: zzw
    > Mail: 819342493@qq.com 
    > Created Time: Mon 15 Apr 2019 07:25:39 PM CST
 ************************************************************************/

#include<stdio.h>
#include<mxml.h>

int main()
{
	//从磁盘中加载xml文件
	FILE*fp = fopen("Car.xml", "r");

	if(fp == NULL)
	{
		printf("file open false!\n");
		return 0;
	}

	mxml_node_t* root = mxmlLoadFile(NULL, fp, MXML_NO_CALLBACK);

	//遍历取出各节点的值 //查看同级
	mxml_node_t* factory = mxmlFindElement(root, root, "factory", NULL, NULL, MXML_DESCEND);
	if(factory == NULL)
	{
		printf("xml node not found\n");
		return 0;
	}
	printf("factory: %s\n", mxmlElementGetAttr(factory, NULL));

	mxml_node_t* brand = mxmlFindElement(factory, root, "brand", NULL, NULL,  MXML_DESCEND);//向下一级搜索
	if(brand==NULL)
	{
		printf("xml node not found\n");
		return 0;
	}

	while(brand)
	{
		printf("==========================\n");

		//向下寻找子标签
		mxml_node_t* node = mxmlWalkNext(brand, root, MXML_DESCEND_FIRST);
		printf("name: %s\n", mxmlGetText(node, NULL));

		//同级寻找
		node = mxmlWalkNext(node, root, MXML_NO_DESCEND);
		printf("color: %s\n", mxmlGetText(node, NULL));
	
		//同级寻找
		node = mxmlWalkNext(node, root, MXML_NO_DESCEND);
		printf("price:  %s\n", mxmlGetText(node, NULL));

		//跳到下一级
		brand = mxmlFindElement(brand, root, "brand", NULL, NULL, MXML_DESCEND);
	}
	fclose(fp);
	mxmlDelete(root);
	return 0;
}

