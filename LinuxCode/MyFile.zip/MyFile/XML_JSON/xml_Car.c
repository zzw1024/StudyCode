/*************************************************************************
    > File Name: xml_create.c
    > Author: zzw
    > Mail: 819342493@qq.com 
    > Created Time: Sun 14 Apr 2019 05:27:21 PM CST
 ************************************************************************/

#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<string.h>
#include<mxml.h>

int main()
{
	//创建新文件
	mxml_node_t* root = mxmlNewXML("1.0");
	//根节点
	mxml_node_t* car = mxmlNewElement(root, "car");

	mxml_node_t* factory = mxmlNewElement(car,"factory");
	mxmlElementSetAttr(factory, "name", "一汽大众" );

	mxml_node_t* brand = mxmlNewElement(factory, "brand");
	mxml_node_t* info = mxmlNewElement(brand, "name");
	mxmlNewText(info, 0, "高尔夫");

	info = mxmlNewElement(brand, "color");
	mxmlNewText(info, 0, "红色");

	info = mxmlNewElement(brand, "price");
	mxmlNewText(info, 0, "15万");

	brand = mxmlNewElement(factory, "brand");
	info = mxmlNewElement(brand, "name");
	mxmlNewText(info, 0, "速腾");

	info = mxmlNewElement(brand, "color");
	mxmlNewText(info, 0, "银白");

	info = mxmlNewElement(brand, "price");
	mxmlNewText(info, 0, "18万");

	brand = mxmlNewElement(factory, "brand");
	info = mxmlNewElement(brand, "name");
	mxmlNewText(info, 0, "迈腾");

	info = mxmlNewElement(brand, "color");
	mxmlNewText(info, 0, "黑灰");

	info = mxmlNewElement(brand, "price");
	mxmlNewText(info, 0, "28万");

	FILE* fp = fopen("Car.xml","w");
	mxmlSaveFile(root, fp, MXML_NO_CALLBACK);

	mxmlDelete(root);
	fclose(fp);

	return 0;
}
