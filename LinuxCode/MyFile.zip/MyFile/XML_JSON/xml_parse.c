/*************************************************************************
    > File Name: xml_parse.c
    > Author: zzw
    > Mail: 819342493@qq.com 
    > Created Time: Sun 14 Apr 2019 08:54:39 PM CST
 ************************************************************************/

#include<stdio.h>
#include<mxml.h>

int main()
{
	//从磁盘中加载xml文件
	FILE* fp = fopen("ChianInfo.mxl", "r");
	if(fp ==  NULL)
	{
		printf("file open false!\n");
		return 0;
	}

	//指向xml
	mxml_node_t* root = mxmlLoadFile(NULL, fp, MXML_NO_CALLBACK);

	//遍历——取出各节点的值
	//找到第一个城市节点
	mxml_node_t* city = mxmlFindElement(root, root, "city", NULL, NULL, MXML_DESCEND);
	if(city == NULL)
	{
		printf("xml node not found\n");
		return 0;
	}

	while(city)
	{
		printf("===================\n");
		//向下走一个节点
		mxml_node_t* node = mxmlWalkNext(city,root, MXML_DESCEND_FIRST);
		printf("city: \n");
		printf("  name = %s\n", mxmlGetText(node, NULL));

		//
		node = mxmlWalkNext(node, root, MXML_NO_DESCEND);
		printf("    area = %s\n", mxmlGetText(node, NULL));

		node = mxmlWalkNext(node, root, MXML_NO_DESCEND);
		printf("    population = %s\n", mxmlGetText(node, NULL));
		
		//搜索下一个城市节点
		city = mxmlFindElement(city, root, "city", NULL, NULL, MXML_DESCEND);
	}
	fclose(fp);
	mxmlDelete(root);
	
	return 0;
}
