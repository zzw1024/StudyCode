/*************************************************************************
	> File Name: environ01.c
	> Author: zhouzhenwen
	> Mail: 819342493@qq.com
	> Created Time: Sun 10 Mar 2019 07:27:14 PM CST
 ************************************************************************/

#include<stdio.h>
extern char **environ;

int main(){
	int i;

	for(i = 0;environ[i];++i){
		printf("%s\n",environ[i]);
	
	}

	return 0;

}
