/*************************************************************************
	> File Name: epoll/epoll.c
	> Author: zhouzhenwen
	> Mail: 819342493@qq.com
	> Created Time: Sun 31 Mar 2019 03:54:28 PM CST
 ************************************************************************/

#include<stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <string.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <ctype.h>
#include <sys/epoll.h>

int main(int argc, const char* argv[])
{
	if(argc < 2)
	{
		printf("请输入端口号！");
		exit(1);
	}
	struct sockaddr_in serv_addr;
	socklen_t serv_len = sizeof(serv_addr);
	int port = atoi(argv[1]);//输入的端口

	//创建套接字
	int lfd = socket(AF_INET, SOCK_STREAM, 0);
	memset(&serv_addr, 0, serv_len);
	serv_addr.sin_family = AF_INET;
	serv_addr.sin_addr.s_addr = htonl(INADDR_ANY);
	serv_addr.sin_port = htons(port);

	//绑定IP端口号
	bind(lfd, (struct sockaddr*)&serv_addr, serv_len);

	listen(lfd, 36);
	printf("Start accept...\n");

	struct sockaddr_in client_addr;
	socklen_t clien_len = sizeof(client_addr);

	//创建epoll树
	int epfd = epoll_create(3000);
	struct epoll_event all[3000];
	struct epoll_event ev;
	ev.events = EPOLLIN | EPOLLET;//设置边沿触发
	ev.data.fd = lfd;
	epoll_ctl(epfd, EPOLL_CTL_ADD, lfd, &ev);

	while(1)
	{
		int ret = epoll_wait(epfd, all, sizeof(all)/sizeof(all[0]), -1);
		printf("*****************epoll_wait****************\n");

		for(int i=0; i<ret; ++i)
		{
			int fd = all[i].data.fd;
			if(fd == lfd)//有新的连接
			{
				//接受连接请求
				int cfd = accept(lfd, (struct sockaddr*)&client_addr, &clien_len);
				if(cfd == -1)
				{
					perror("accpet error!");
					exit(1);
				}

				//将新得到的连接挂在树上
				struct epoll_event temp;
				temp.events = EPOLLIN | EPOLLET;//设置边沿触发
				temp.data.fd = cfd;
				epoll_ctl(epfd, EPOLL_CTL_ADD, cfd, &temp);//上树
				
				//打印客户消息
				char ip[1024] = {0};
				printf("New Client IP:%s, port: %d \n",
						inet_ntop(AF_INET, &client_addr.sin_addr.s_addr, ip, sizeof(ip)),
						ntohs(client_addr.sin_port));
			}
			else
			{
				if(!all[i].events & EPOLLIN)
					continue;
				char buf[1024] = {0};
				int len = recv(fd, buf, sizeof(buf), 0);
				if(len == -1)
				{
					printf("recv error!");
					exit(1);
				}
				else if(len == 0)
				{
					printf("client disconnected ....\n");
					ret = epoll_ctl(epfd, EPOLL_CTL_ADD, fd, NULL);
					if(ret == -1)
					{
						printf("epoll_ctl - del error!");
						exit(1);
					}
					close(fd);
				}
				else
				{
					//printf("recv buf:%s\n", buf);//直接输出
					write(STDOUT_FILENO, buf, len);//写到后台
					write(fd,buf,len);
				}
			}
		}
				
	}
	close (lfd);
	return 0;


}
