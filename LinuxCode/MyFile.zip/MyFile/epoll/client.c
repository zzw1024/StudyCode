/*************************************************************************
	> File Name: client.c
	> Author: zhouzhenwen
	> Mail: 819342493@qq.com
	> Created Time: Tue 26 Mar 2019 07:12:53 PM CST
 ************************************************************************/

#include<stdio.h>
#include <string.h>
#include <unistd.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdlib.h>

#define MAXLINE 8192

int main(int argc, char *argv[]){
	if(argc<2)
	{
		printf("输入端口号！");
		exit(1);
	}
	struct sockaddr_in servaddr;
	char buf[MAXLINE];
	int sockfd, n;
	int portNum = atoi(argv[1]); 

	sockfd = socket(AF_INET, SOCK_STREAM, 0);

	bzero(&servaddr, sizeof(servaddr));
	servaddr.sin_family = AF_INET;
	inet_pton(AF_INET,"127.0.0.1",&servaddr.sin_addr);
	servaddr.sin_port = htons(portNum);

	connect(sockfd,(struct sockaddr *)&servaddr,sizeof(servaddr));

	while(fgets(buf,MAXLINE,stdin)!=NULL){
		write(sockfd,buf,strlen(buf));
		n = read(sockfd,buf,MAXLINE);
		if(n==0){
			printf("the other side has been closed.\n");
			break;
		}
		else
			write(STDOUT_FILENO, buf, n);	
	}

	close(sockfd);
	return 0;
}
