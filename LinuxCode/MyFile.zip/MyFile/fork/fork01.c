/*************************************************************************
	> File Name: fork01.c
	> Author: zhouzhenwen
	> Mail: 819342493@qq.com
	> Created Time: Sun 10 Mar 2019 07:49:52 PM CST
 ************************************************************************/

#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
int main(){
	
	pid_t pid;
	pid = fork();
	if(pid < 0){
		perror("fork is false!");
		exit(1);
	}else if(pid >0 ){ //this is the father pid_t
		printf("I am the father fork()! my pid is: %d\n",getpid());
					
	}else{
		sleep(3);
		printf("I am the son fork(), my pid is : %d\n",getpid());
//		execl("/bin/ls","ls","-1",NULL);
//		perror("excel");
//		exit(1);
	
	}
	
	printf("----------finish------%d\n",getpid());

	return 0;


}
