/*************************************************************************
  > File Name: fork_zoom.c
  > Author: zhouzhenwen
  > Mail: 819342493@qq.com
  > Created Time: Sun 10 Mar 2019 11:14:08 PM CST
 ************************************************************************/

#include<stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int main(void)
{
	pid_t pid, wpid;
	pid = fork();

	if (pid == 0) {
		printf("---child, my parent= %d, going to sleep 10s\n", getppid());
		sleep(10);
		printf("-------------child die--------------\n");
	} else if (pid > 0) {
		while (1) {
			printf("I am parent, pid = %d, myson = %d\n", getpid(), pid);
			sleep(1);
		}
	} else {
		perror("fork");
		return 1;
	}

	return 0;
}
