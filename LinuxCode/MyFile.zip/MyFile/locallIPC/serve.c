/*************************************************************************
  > File Name: broadcast.c
  > Author: zzw
  > Mail: 819342493@qq.com 
  > Created Time: Wed 03 Apr 2019 10:03:24 PM CST
 ************************************************************************/

#include<stdio.h>
#include<unistd.h>
#include <sys/types.h>          /* See NOTES */
#include <sys/socket.h>
#include <stdlib.h>
#include <string.h>
#include <arpa/inet.h>
#include <stdarg.h>
#include <sys/stat.h>
#include <sys/un.h>

int main(int agc, char *agv[])
{
	//创建套接字
	int lfd = socket(AF_LOCAL, SOCK_DGRAM, 0);
	if(lfd == -1)
	{
		perror("socket error!\n");
		exit(1);
	}
	//如果套接字文件存在，删除套接字文件
	unlink("server.sock");

		//绑定
	struct sockaddr_un serv;
	//memset(&serv, 0, sizeof(serv));
	serv.sun_family = AF_LOCAL;
	strcpy(serv.sun_path, "server.sock");
	int ret = bind(lfd, (struct sockaddr*)&serv, sizeof(serv));

	if(ret == -1)
	{
		perror("bind error!\n");
		exit(1);
	}

	//监听
	ret = listen(lfd, 36);
	if(ret == -1)
	{
		perror("listen error!\n");
		exit(1);
	}


	//初始化客户端信息
	struct sockaddr_un client;
	//memset(&client, 0, sizeof(client));
	//client.sin_family = AF_INET;
	//client.sin_port = htons(6767);//由于使用本地机测试，故不能使用同一端口

	//使用广播给客户端发送信息
	//inet_pton(AF_INET,"192.168.233.255",&client.sin_addr.s_addr);

	//开通广播权限
	//int flag  = 1;
	//setsockopt(lfd, SOL_SOCKET, SO_BROADCAST, &flag, sizeof(flag));
	socklen_t len = sizeof(client);
	int cfd = accept(lfd, (struct sockaddr *)&client, &len);
	if(cfd == -1)
	{
		perror("accept error\n");
		exit(1);
	}
	printf("==========client bindd file:%s\n",client.sun_path);
	//通信
	while(1)
	{

		char buf[1024] = {0};
		int recvlen = recv(cfd, buf, sizeof(buf), 0);
		if(recvlen == -1)
		{
			perror("recv error");
			exit(1);
		}
		else if(recvlen == 0)
		{
			printf("clietn disconnect ....\n");
			close(cfd);
			break;
		}
		else
		{
			printf("recv buf: %s\n", buf);
			send(cfd, buf, recvlen, 0);
		}
	}
	close(lfd);
	close(cfd);
	return 0;
}
