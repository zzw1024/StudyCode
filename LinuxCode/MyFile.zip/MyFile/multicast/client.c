/*************************************************************************
    > File Name: client.c
    > Author: zzw
    > Mail: 819342493@qq.com 
    > Created Time: Thu 04 Apr 2019 09:48:09 PM CST
 ************************************************************************/

#include<stdio.h>
#include<string.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<unistd.h>
#include<stdlib.h>
#include<sys/stat.h>
#include<arpa/inet.h>
#include<net/if.h>


int main()
{
	int lfd = socket(AF_INET, SOCK_DGRAM, 0);
	if(lfd == -1)
	{
		perror("socket error!\n");
		exit(1);
	}
	struct sockaddr_in client;
	memset(&client, 0, sizeof(client));
	client.sin_family = AF_INET;
	client.sin_port = htons(6767);
	//使用广播进行发送数据
	inet_pton(AF_INET, "0.0.0.0",&client.sin_addr.s_addr);
	int ret = bind(lfd, (struct sockaddr*)&client, sizeof(client));

	if(ret == -1)
	{
		perror("bind error!\n");
		exit(1);
	}
	//加入到组播地址中
	struct ip_mreqn fl;
	inet_pton(AF_INET, "239.0.0.10", &fl.imr_multiaddr.s_addr);
	inet_pton(AF_INET,"0.0.0.0", &fl.imr_address.s_addr);
	fl.imr_ifindex = if_nametoindex("ens33");
	setsockopt(lfd, IPPROTO_IP, IP_ADD_MEMBERSHIP, &fl, sizeof(fl));

	//接受数据
	while(1)
	{
		char buf[1024] = {0};
		int len = recvfrom(lfd, buf, sizeof(buf), 0, NULL, NULL);
		if(len == -1)
		{
			perror("recvfrom error!\n");
			exit(1);
		}

		printf("client == recv buf : %s\n",buf);
		
	}

	close (lfd);
	return 0;
	
}
