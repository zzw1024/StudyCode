#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <string.h>
#include <arpa/inet.h>
#include <netinet/in.h>

#define SERV_PORT  6666
#define MAXLINE 80

int main(int argc, const char* argv[])
{

    // 连接服务器
    struct sockaddr_in serv_addr;
	char buf[MAXLINE];

	int lfd = socket(AF_INET,SOCK_STREAM,0);

    bzero(&serv_addr, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(SERV_PORT);
    inet_pton(AF_INET, "127.0.0.1", &serv_addr.sin_addr);

    connect(lfd, (struct sockaddr*)&serv_addr, sizeof(serv_addr));

    // 通信
    while(1)
    {
        // 从终端读一个字符串
        char buf[MAXLINE] = {0};
        fgets(buf, MAXLINE, stdin);
        // 发数据
        write(lfd, buf, strlen(buf)+1);

        // 接收
        // 阻塞等待
        int len = read(lfd, buf, sizeof(buf));
        if(len == -1)
        {
            perror("read error");
            exit(1);
        }
		else if(len == 0)
			printf("the other side has been closed\n");
		else
		{
			printf("read buf = %s\n", buf);
			write(STDOUT_FILENO, buf, len);
		}
        
    }

    close(lfd);

    return 0;
}
