/*************************************************************************
    > File Name: test.c
    > Author: zzw
    > Mail: 819342493@qq.com 
    > Created Time: Thu 11 Apr 2019 10:41:03 AM CST
 ************************************************************************/

#include<stdio.h>

int main(){

	int a = 10;
	int b[a];
	return 0;
}
