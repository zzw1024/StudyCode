/*************************************************************************
  > File Name: waitpid01.c
  > Author: zhouzhenwen
  > Mail: 819342493@qq.com
  > Created Time: Sun 10 Mar 2019 08:11:34 PM CST
 ************************************************************************/

#include<stdio.h>
#include<unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>


int main(){
	
	pid_t pid;

	int status;

	pid = fork();

	if(pid < 0){
		perror("fork");
		exit(4);
	}else if(pid == 0){
		sleep(1);
		printf("i am son, sleeping ,pid = %d\n",getpid());
		sleep(5);
#if 0
		exit(1);
		execl("./abnor","abnor",NULL);
		perror("execl error");
		sleep(1);
		exit(10);
#endif
		while(1);
	}else{
		printf("i am father, waiting son died. pid = %d\n",getpid());
		wait(&status);
		printf(" my son is died!\n");
		if(WIFEXITED(status))
			printf("son exit is normal!\n");
		else if(WIFSIGNALED(status))
			printf("son is killed!\n");
		else
			printf("other...\n");
	
	}


}
	









