/*************************************************************************
  > File Name: waitpid01.c
  > Author: zhouzhenwen
  > Mail: 819342493@qq.com
  > Created Time: Sun 10 Mar 2019 08:11:34 PM CST
 ************************************************************************/

#include<stdio.h>
#include<unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>


int main(){
	
	pid_t pid;
	pid = fork();

	if(pid<0){
		perror("fork error!");
		exit(2);
	}else if(pid == 0){
		sleep(5);
		printf("i am son, my pid = %d\n",getpid());
		
	}else{
		printf("i am father, my pid = %d\n",getpid());
		pid_t wpid = wait(NULL);
		if(wpid < 0)
			perror("wpid");
		printf("i have waited my son died! my pid is = %d\n",getpid());
	
	
	}
	return 0;

}










