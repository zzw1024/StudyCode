/*************************************************************************
  > File Name: waitpid01.c
  > Author: zhouzhenwen
  > Mail: 819342493@qq.com
  > Created Time: Sun 10 Mar 2019 08:11:34 PM CST
 ************************************************************************/

#include<stdio.h>
#include<unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>

int main(){
	pid_t pid;
	pid = fork();
	if(pid<0){
		perror("fork()");
		exit(1);		
	}else if(pid == 0){//this is the son
		int i=1000;
		sleep(2);
		while(i<1010){
			printf("%di am the son, you can't kill me! my pid is = %d\n",i++,getpid());	

		}
		exit(3);
	}
	else{//the father
		printf("i am father! my pid = %d\n",getpid());
		int status;
		waitpid(pid, &status, 0);//stop at here

		if(WIFEXITED(status))
			printf("the son exit at commal!^_^\n");
		else if(WEXITSTATUS(status))
			printf("the signal is break!");

	}
	return 0;


}







