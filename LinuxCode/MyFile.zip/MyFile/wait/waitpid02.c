/*************************************************************************
  > File Name: waitpid01.c
  > Author: zhouzhenwen
  > Mail: 819342493@qq.com
  > Created Time: Sun 10 Mar 2019 08:11:34 PM CST
 ************************************************************************/

#include<stdio.h>
#include<unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>

int main(){
	pid_t pid, pid2, wpid;
	int flag = 0;

	pid = fork();
	pid2 = fork();


	if(pid<0){
		perror("fork()");
		exit(1);		
	}else if(pid == 0){//this is the son
		int i=1000;
		sleep(5);
		while(i<1010){
			printf("%d   i am the son, you can't kill me! my pid is = %d\n",i++,getpid());	
			exit(4);
		}
	}else{
		do{
			sleep(1);
			wpid = waitpid(pid, NULL, WNOHANG);
			printf("----wpid = %d ----%d\n",wpid, flag++);
			if(wpid==0){
				printf("No child exited\n");
				sleep(1);				
			}
		}while(wpid==0);

		if(wpid==pid)
			printf("i am father,i catched a child process!\n");
		else
			printf("other....\n");

	}
	return 0;
}











