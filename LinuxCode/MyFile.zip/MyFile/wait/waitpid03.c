/*************************************************************************
  > File Name: waitpid01.c
  > Author: zhouzhenwen
  > Mail: 819342493@qq.com
  > Created Time: Sun 10 Mar 2019 08:11:34 PM CST
 ************************************************************************/

#include<stdio.h>
#include<unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>

int main(){

	int n = 5, i;
	pid_t pid;
	for( i = 0; i < n; ++i){
		pid = fork();
		if(pid == 0)
			break;
	}

	if(i == n){
		sleep(n);
		printf("i am father, my pid is=%d", getpid());
		for(i = 0;i<n;++i){
			pid_t p = waitpid(0,NULL,WNOHANG);
			printf("wait pid = %d\n",p);		
		}
	}else{
		
		sleep(i);
		printf("i = %d   i am son, my pid is = %d\n",i,getpid());
	//	while(1);
	
	}

}










