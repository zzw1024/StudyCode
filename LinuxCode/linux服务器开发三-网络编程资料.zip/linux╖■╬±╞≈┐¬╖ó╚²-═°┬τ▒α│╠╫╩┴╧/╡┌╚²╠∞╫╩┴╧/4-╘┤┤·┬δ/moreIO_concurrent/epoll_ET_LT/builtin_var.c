#include <stdio.h>

int main(void)
{
    printf("%s\n%s\n", __func__, __FILE__);

    return 0;
}
