# Python3 Scrapy 爬虫项目
```shell
# 请检查环境
[root@centos ~] python3 -v 
Python 3.7.2
[root@centos ~] scrapy version
Scrapy 1.6.0
```
### 计划爬取平台：
- [x] 喜马拉雅
- [x] 懒人听书
- [x] 蜻蜓FM
- [ ] 企鹅FM
- [ ] 荔枝FM


### 申明：
仅供个人学习研究和交流使用，请于下载后二十四小时内删除