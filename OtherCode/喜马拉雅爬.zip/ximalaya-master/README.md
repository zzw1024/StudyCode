# ximalaya
![shotscreen](./shotscreen.png)
喜马拉雅听书 有声书爬虫, 可以爬取得到有声书的音频地址, 存在本地为json格式, 后续可以直接按照链接来下载音频/存到数据库中
