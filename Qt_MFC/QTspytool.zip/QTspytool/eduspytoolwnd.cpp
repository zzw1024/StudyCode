﻿#include <QSplitter>
#include <QHBoxLayout>
#include <QList>
#include <QObject>
#include <QObjectList>
#include <QTreeWidgetItem>
#include <QAction>
#include <QHeaderView>
#include <QCursor>
#include <QWindow>
#include <QApplication>
#include <QDebug>
#include <QToolBar>
#include "eduspytoolwnd.h"


EduSpytoolWindow::EduSpytoolWindow(QWidget* parent)
	:QMainWindow(parent)
{
	QApplication::instance()->installEventFilter(this);//安装事件过滤器；
	setAttribute(Qt::WA_DeleteOnClose, true);
	resize(1362, 762);
	//添加开始和关闭按钮
	m_startUseButton = new QToolButton(this);
	m_startUseButton->setIcon(QIcon(":/pic/start.png"));
	m_startUseButton->setToolButtonStyle(Qt::ToolButtonIconOnly);
	connect(m_startUseButton, &QToolButton::clicked, this, &EduSpytoolWindow::startEventFilter);
	QToolBar *pToolBar = new QToolBar(this);
	pToolBar->addWidget(m_startUseButton);
	pToolBar->setMovable(false);
	addToolBar(pToolBar);
	//中央widget，用来布局的
	m_centerWiget = new QWidget(this);
	setCentralWidget(m_centerWiget);
	//父子空间展示列表
	m_treeWidget = new QTreeWidget(m_centerWiget);
	m_treeWidget->setHeaderHidden(true);//隐藏表头
	m_menu = new QMenu(m_centerWiget);//此处注意一下
	QAction *pHighLight = new QAction(u8"高亮显示");
	connect(pHighLight, &QAction::triggered, this, &EduSpytoolWindow::highLightTheObject);
	QAction *pListenMessage = new QAction(u8"监听消息");
	connect(pListenMessage, &QAction::triggered, this, &EduSpytoolWindow::listenObjectMessage);
	m_menu->addAction(pHighLight);
	m_menu->addAction(pListenMessage);
	connect(m_treeWidget, &QTreeWidget::clicked, this, &EduSpytoolWindow::showObjectAttribute);
	//属性展示表格
	m_tableWidget = new QTableWidget(m_centerWiget);
	m_tableWidget->setColumnCount(2);//设置2列
	m_tableWidget->horizontalHeader()->setStretchLastSection(true); //均分各列
	m_tableWidget->setHorizontalHeaderLabels({ u8"属性",u8"值" });
	m_tableWidget->horizontalHeader()->setSectionsClickable(false);//设置表头不可点击
	m_tableWidget->verticalHeader()->setVisible(false);//设置列表头不显示
	m_tableWidget->setSelectionBehavior(QAbstractItemView::SelectRows);//点击则选择一行
	m_tableWidget->setEditTriggers(QAbstractItemView::DoubleClicked);// 双击可编辑
	
	QSplitter *pSplitter = new QSplitter(Qt::Orientation::Horizontal,m_centerWiget);
	pSplitter->addWidget(m_treeWidget);
	pSplitter->addWidget(m_tableWidget);

	QHBoxLayout *pHLayout = new QHBoxLayout();
	pHLayout->setSpacing(0);
	pHLayout->setContentsMargins(0, 0, 0, 0);
	pHLayout->addWidget(pSplitter);
	m_centerWiget->setLayout(pHLayout);
	//高亮蒙面窗口
	m_widgetDialog = new QDialog(nullptr);
	m_widgetDialog->setAttribute(Qt::WA_TransparentForMouseEvents, true);//设置信号穿透，一定放在前面才会生效
	m_widgetDialog->setAttribute(Qt::WA_DeleteOnClose, true);
	m_widgetDialog->setWindowFlags(Qt::Dialog | Qt::FramelessWindowHint);// | Qt::WindowStaysOnTopHint);	//去除标题
	m_widgetDialog->setStyleSheet(QString("border:%1px solid red").arg(QString::number(m_borderWidth)));//
	m_widgetDialog->setWindowOpacity(0.5);//设置透明度
	m_widgetDialog->show();
	m_widgetDialog->setVisible(false);

	m_timer = new QTimer(this);
	m_timer->setInterval(100);
	connect(m_timer, &QTimer::timeout, this, &EduSpytoolWindow::onTimerTimeOut);
}

EduSpytoolWindow::~EduSpytoolWindow() 
{
	if (m_widgetDialog)
	{
		m_widgetDialog->close();
		delete m_widgetDialog;
	}
}

void EduSpytoolWindow::findParentWidget(QObject *obj)
{
	this->activateWindow();//激活窗口，窗口显示在前面
	//清空内存
	m_objectItem.clear();
	m_widgetHash.clear();//存储父子控件关系
	m_treeWidget->clear();

	findAllChildWidget(m_parentObject);

	QTreeWidgetItem *item = new QTreeWidgetItem(m_treeWidget);
	m_currentItem = item;
	QString pItemName = QString(m_parentObject->metaObject()->className()) + "_"\
		+ QString(m_parentObject->objectName() == "" ? "unnamed" : m_parentObject->objectName());
	item->setText(0, pItemName);
	m_objectItem[item] = m_parentObject;//【要保证唯一性】
	addTreeWidgetItems(m_parentObject, item);
}

void EduSpytoolWindow::findAllChildWidget(QObject *obj)
{
	QObjectList pList = obj->children();
	for(QObject *var : pList)
	{
		m_widgetHash[obj].insert(var);
		if (!(var->children()).empty())
		{
			findAllChildWidget(var);
		}
	}
}

void EduSpytoolWindow::addTreeWidgetItems(QObject *obj, QTreeWidgetItem *parentItem)
{
	QObject *parent = obj;
	QSet<QObject*>list = m_widgetHash[parent];
	for(QObject *var : list)
	{
		QTreeWidgetItem *item = new QTreeWidgetItem();
		QString pItemName = QString(var->metaObject()->className()) + "_" \
			+ QString((var->objectName() == "" ? "unnamed" : var->objectName()));
		item->setText(0, pItemName);
		if(var==m_currentObject)
			m_currentItem = item;//找到选中对象在treeWidget的位置
		m_objectItem[item] = var;
		parentItem->addChild(item);		
		if (!m_widgetHash[var].empty())//此obj也是父窗口
		{
			addTreeWidgetItems(var, item);
		}
	}
	m_treeWidget->setCurrentItem(m_currentItem);
}

void EduSpytoolWindow::highLightTheObject()
{
	QTreeWidgetItem *item = m_treeWidget->currentItem();
	QObject *obj = m_objectItem[item];
	QWidget *widget = qobject_cast<QWidget*>(obj);
	if (widget == nullptr)
	{
		return;
	}
	m_widgetDialog->setVisible(false);
	m_widgetDialog->resize(widget->size());
	m_widgetDialog->move(widget->mapToGlobal(QPoint(0, 0)) - QPoint(m_borderWidth, m_borderWidth));
	m_timer->start();
}

void EduSpytoolWindow::listenObjectMessage()
{

}

void EduSpytoolWindow::onTimerTimeOut()
{
	if (m_showTimes--)
	{
		if (m_showTimes % 2 == 0)
		{
			m_widgetDialog->setVisible(false);
		}
		else
		{
			m_widgetDialog->setVisible(true);
		}
	}
	else
	{
		m_showTimes = 10;
		m_timer->stop();
		m_widgetDialog->setVisible(false);
	}
}

void EduSpytoolWindow::contextMenuEvent(QContextMenuEvent *event)//添加右击菜单
{
	QTreeWidgetItem *item = m_treeWidget->currentItem();
	m_menu->exec(QCursor::pos());
}

void EduSpytoolWindow::showObjectAttribute()
{
	m_tableWidget->setRowCount(0);
	m_tableWidget->clearContents();

	QTreeWidgetItem *item = m_treeWidget->currentItem();
	QObject *obj = m_objectItem[item];
	QWidget *widget = qobject_cast<QWidget*>(obj);
	if (widget == nullptr)
	{
		return;
	}
	//对象名称
	int currRow = m_tableWidget->rowCount();//当前行
	m_tableWidget->insertRow(currRow);//插入一行
	QTableWidgetItem* item00 = new QTableWidgetItem("objectName");
	item00->setFlags(item00->flags() & (~Qt::ItemIsEditable));//设置文字不可修改
	m_tableWidget->setItem(currRow, 0, item00);
	QTableWidgetItem* item01 = new QTableWidgetItem(obj->objectName());
	//item1->setFlags(item1->flags() & Qt::ItemIsEditable);//设置文字不可修改
	m_tableWidget->setItem(currRow, 1, item01);
	//keyTable->item(currRow, 0)->setTextAlignment(Qt::AlignHCenter | Qt::AlignVCenter);	//文字居中
	++currRow;

	//对象类型
	m_tableWidget->insertRow(currRow);//插入一行
	QTableWidgetItem* item10 = new QTableWidgetItem("className");
	item10->setFlags(item10->flags() & (~Qt::ItemIsEditable));//设置文字不可修改
	m_tableWidget->setItem(currRow, 0, item10);
	QTableWidgetItem* item11 = new QTableWidgetItem(obj->metaObject()->className());
	m_tableWidget->setItem(currRow, 1, item11);
	++currRow;

	//控件大小
	m_tableWidget->insertRow(currRow);//插入一行
	QTableWidgetItem* item20 = new QTableWidgetItem("size");
	item20->setFlags(item20->flags() & (~Qt::ItemIsEditable));//设置文字不可修改
	m_tableWidget->setItem(currRow, 0, item20);
	QTableWidgetItem* item21 = new QTableWidgetItem(QString::number(widget->size().width()) + "," + QString::number(widget->size().height()));
	m_tableWidget->setItem(currRow, 1, item21);
	++currRow;

	//控件位置
	m_tableWidget->insertRow(currRow);//插入一行
	QTableWidgetItem* item30 = new QTableWidgetItem("pos");
	item30->setFlags(item30->flags() & (~Qt::ItemIsEditable));//设置文字不可修改
	m_tableWidget->setItem(currRow, 0, item30);
	QTableWidgetItem* item31 = new QTableWidgetItem(QString::number(widget->pos().x()) + "," + QString::number(widget->pos().y()));
	m_tableWidget->setItem(currRow, 1, item31);
	++currRow;

	//全局位置
	m_tableWidget->insertRow(currRow);//插入一行
	QTableWidgetItem* item40 = new QTableWidgetItem("globalPos");
	item40->setFlags(item40->flags() & (~Qt::ItemIsEditable));//设置文字不可修改
	m_tableWidget->setItem(currRow, 0, item40);
	QTableWidgetItem* item41 = new QTableWidgetItem(QString::number(widget->mapToGlobal(widget->pos()).x()) + "," + QString::number(widget->mapToGlobal(widget->pos()).y()));
	m_tableWidget->setItem(currRow, 1, item41);
	++currRow;
}

//事件过滤器
bool EduSpytoolWindow::eventFilter(QObject *obj, QEvent *event)
{
	QWidget *widget = qobject_cast<QWidget*>(obj);
	if (!isStartEventFilter || widget == nullptr)//未打开功能
	{
		return QMainWindow::eventFilter(obj, event);
	}
	QObject *child = obj;
	QObject *parent = obj;
	while (parent != nullptr)
	{
		child = parent;
		parent = child->parent();
	}
	m_parentObject = child;
	m_currentObject = obj;
	if (m_parentObject != this && obj->inherits("QWidget"))
	{
		if (event->type() == QEvent::Enter)
		{			
			m_widgetDialog->resize(widget->size() + QSize(m_borderWidth * 2, m_borderWidth * 2));
			m_widgetDialog->move(widget->mapToGlobal(QPoint(0, 0)) - QPoint(m_borderWidth, m_borderWidth));//【使用全局坐标导致获取不到对象】
			m_widgetDialog->setVisible(true);
			return true;
		}
		else if (event->type() == QEvent::Leave)
		{
			m_widgetDialog->setVisible(false);
			return true;
		}
		else if (event->type() == QEvent::MouseButtonPress)
		{
			findParentWidget(obj);
			return true;
		}
		return false;
	}
	return QMainWindow::eventFilter(obj, event);
}

//打开和关闭事件过滤
void EduSpytoolWindow::startEventFilter()
{
	if (isStartEventFilter)//打开了
	{
		m_startUseButton->setIcon(QIcon(":/pic/start.png"));
		m_startUseButton->setDown(false);
	}
	else
	{
		m_startUseButton->setIcon(QIcon(":/pic/stop.png"));
		m_startUseButton->setDown(true);
	}
	isStartEventFilter = !isStartEventFilter;
}