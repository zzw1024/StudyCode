﻿#ifndef _EDUSPYTOOLWND_H_
#define _EDUSPYTOOLWND_H_
#include <QMainWindow>
#include <QWidget>
#include <QTreeWidget>
#include <QTableWidget>
#include <QSet>
#include <QHash>
#include <QMenu>
#include <QEvent>
#include <QTimer>
#include <QDialog>
#include <QPointer>
#include <QToolButton>
#include <QContextMenuEvent>

class EduSpytoolWindow : public QMainWindow
{
	Q_OBJECT
public:
	explicit EduSpytoolWindow(QWidget* parent = nullptr);
	~EduSpytoolWindow();

private:
	QWidget *m_centerWiget = nullptr;
	QTreeWidget *m_treeWidget = nullptr;
	QTableWidget *m_tableWidget = nullptr;
	QPointer<QDialog>m_widgetDialog = nullptr;//给控件一个蒙面
	QTimer *m_timer = nullptr;
	QToolButton *m_startUseButton = nullptr;
	QMenu *m_menu = nullptr;//右击菜单
	QHash<QTreeWidgetItem*, QObject*>m_objectItem;//通过项目找到对象
	QHash<QObject*, QSet<QObject*>> m_widgetHash;//存储父子控件关系
	QObject *m_parentObject = nullptr;
	QObject *m_currentObject = nullptr;
	QTreeWidgetItem *m_currentItem = nullptr;

	int m_showTimes = 10;//高亮闪动时间
	int m_borderWidth = 2;//高亮宽度
	bool isStartEventFilter = false;//需要手动打开事件过滤

public slots:
	void findParentWidget(QObject *obj);
	void highLightTheObject();
	void listenObjectMessage();
	void onTimerTimeOut();
	void startEventFilter();

private:
	void findAllChildWidget(QObject *object);
	void showObjectAttribute();
	void addTreeWidgetItems(QObject *obj, QTreeWidgetItem *parentItem);
	void contextMenuEvent(QContextMenuEvent *event);//添加右击菜单

protected:
	bool eventFilter(QObject *obj, QEvent *event);

};



#endif