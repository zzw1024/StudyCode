#include "button.h"
#include <QDebug>
#include <QPushButton>
Button::Button(QWidget *parent) : QPushButton(parent)
{

}

Button::~Button()
{
    qDebug() << "Button is deleting...";
}
