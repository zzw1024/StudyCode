﻿#include "widget.h"
#include <QApplication>
#include "button.h" //包含头文件  应用程序

int main(int argc, char *argv[])//程序入口 argc命令行变量  argv命令行变量数组
{
    //应用程序对象，有且仅有一个应用程序对象
    QApplication a(argc, argv);
   // QTextCodec::setCodecForCStrings(QTextCodec::codecForLocale());

    //QTextCodec::setCodecForTr(QTextCodec::codecForName("utf-8"));
    //创建my_widge对象  基类为：QWidge
    Widget w;
     //窗口默认不会弹出，show函数是让窗口弹出函数
    w.show();
    //进入循环机制，即pause作用相同
    return a.exec();
}
