﻿#include "widget.h"
#include "button.h"
#include <QPushButton>
#include <QDebug>
#pragma execution_character_set("utf-8")
Widget::Widget(QWidget *parent)
    : QWidget(parent)
{
    //set a button
    QPushButton *btn = new QPushButton;
//    btn->show();//show the new build button
    btn->setParent(this);  //set the parent
    btn->setText("按钮");//set a name for the new button

    //build an another new button
    //创建并直接赋值名字和父类
    QPushButton * btn2 = new QPushButton("按钮2",this);
    //set the size of window
    resize(650,400);
    btn2->move(150,150);
    btn2->resize(50,50);  //set the size of the new button

    setWindowTitle("测试窗口");

    //create a myself button
    Button *myBtn = new Button;
    myBtn->setText("自己的按钮");
    myBtn->setParent(this);
    myBtn->resize(50,30);
    myBtn->move(250,250);

    //connect the signal with the button
    connect(myBtn,&QPushButton::clicked, this, &QWidget::close);


}

Widget::~Widget()
{
    qDebug() << "widget is deleting...";
}
