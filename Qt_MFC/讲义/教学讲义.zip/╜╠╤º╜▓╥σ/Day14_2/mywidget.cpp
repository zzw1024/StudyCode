#include "mywidget.h"

MyWidget::MyWidget(QWidget *parent)
    : QWidget(parent)
{
    teacher = new Teacher(this);
    student = new Student(this);

    //connet the student and teacher
    connect(teacher,&Teacher::hungry, student, &Student::treat);

    //class is over!
    classOver();
}

void MyWidget::classOver()
{
    //触发老师饿了的信号
    //老师饿了的信号属于自定义信号，触发自定义信号关键字  emit
    emit teacher->hungry();
}

MyWidget::~MyWidget()
{

}
