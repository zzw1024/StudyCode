#ifndef STUDENT_H
#define STUDENT_H

#include <QObject>

class Student : public QObject
{
    Q_OBJECT
public:
    explicit Student(QObject *parent = 0);//防止函数中的隐式类型转换，即hh(20)等类型
signals:

public slots:
    //自定义信息槽函数
    void treat();

};

#endif // STUDENT_H
