#include "teacher.h"
#include <QDebug>
Teacher::Teacher(QObject *parent ) : QObject (parent)
{

}

void Teacher::hungry()
{
    qDebug()<<"I am hungry!";
}
