#ifndef TEACHER_H
#define TEACHER_H
#include <QObject>

class Teacher : public QObject
{
    Q_OBJECT
public:
    explicit Teacher(QObject *parent = 0);

signals:

public slots:
    //自定义信息槽函数
    void hungry();
};

#endif // TEACHER_H


