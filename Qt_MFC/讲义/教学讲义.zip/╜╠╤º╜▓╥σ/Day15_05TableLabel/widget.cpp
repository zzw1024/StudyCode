#include "widget.h"
#include "ui_widget.h"
#include <QMessageBox>
#pragma execution_character_set("utf-8")


Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);

    //QTableWidget�ؼ���ʹ�÷���
    QStringList list;
    list << "����" << "�Ա�" << "����" ;
    ui->tableWidget->setColumnCount(list.size());
    //����ˮƽͷ
    ui->tableWidget->setHorizontalHeaderLabels(list);
    //��������
    ui->tableWidget->setRowCount(5);

    //��������
    ui->tableWidget->setItem(0,0,new QTableWidgetItem("��ɪ"));
    ui->tableWidget->setItem(0,1,new QTableWidgetItem("��"));
    ui->tableWidget->setItem(0,2,new QTableWidgetItem(QString::number(18)));

    ui->tableWidget->setItem(1,0,new QTableWidgetItem("槼�"));
    ui->tableWidget->setItem(1,1,new QTableWidgetItem("Ů"));
    ui->tableWidget->setItem(1,2,new QTableWidgetItem(QString::number(17)));

    ui->tableWidget->setItem(2,0,new QTableWidgetItem("������"));
    ui->tableWidget->setItem(2,1,new QTableWidgetItem("Ů"));
    ui->tableWidget->setItem(2,2,new QTableWidgetItem(QString::number(19)));

    ui->tableWidget->setItem(3,0,new QTableWidgetItem("����̫һ"));
    ui->tableWidget->setItem(3,1,new QTableWidgetItem("��"));
    ui->tableWidget->setItem(3,2,new QTableWidgetItem(QString::number(32)));

    ui->tableWidget->setItem(4,0,new QTableWidgetItem("���"));
    ui->tableWidget->setItem(4,1,new QTableWidgetItem("��"));
    ui->tableWidget->setItem(4,2,new QTableWidgetItem(QString::number(24)));

    //add the zhaoyun
    connect(ui->addBtn,&QPushButton::clicked,[=](){
        //judge there have any zhaoyun
        bool isEmpty = ui->tableWidget->findItems("����",Qt::MatchExactly).empty();

        if(isEmpty)//there is no zhaoyun
        {
            ui->tableWidget->insertRow(0);
            ui->tableWidget->setItem(0,0,new QTableWidgetItem("����"));
            ui->tableWidget->setItem(0,1,new QTableWidgetItem("��"));
            ui->tableWidget->setItem(0,2,new QTableWidgetItem(QString::number(18)));
            QMessageBox::information(this,"Infor","add OK!");
        }
        else
        {
            QMessageBox::warning(this,"Warning","zhaoyun is alreday!");
        }
    });

    connect(ui->deleteBtn,&QPushButton::clicked,[=](){
        //judge there have any zhaoyun
        bool isEmpty = ui->tableWidget->findItems("����",Qt::MatchExactly).empty();

        if(isEmpty)//there is no zhaoyun
        {
            QMessageBox::warning(this,"Warning","there is no zhaoyun!");
        }
        else
        {
            //find the zhaoyun's local
            int row = ui->tableWidget->findItems("����",Qt::MatchExactly).first()->row();
            //delete
            ui->tableWidget->removeRow(row);
        }

    });
}


Widget::~Widget()
{
    delete ui;
}
