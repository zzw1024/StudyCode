#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QDialog>
#include <QDebug>
#include <QMessageBox>
#include <QColorDialog>
#include <QFileDialog>


MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    //通过ui寻找控件
    //ui->actionNew->setIcon(QIcon("E:/Image/Luffy.png"));
    //添加资源文件 到项目中
    //使用资源文件 " : + 前缀名 + 文件名 "

    //点击新建菜单项，弹出对话框
    connect(ui->actionNew,&QAction::triggered,this,[=](){
    // 模态对话框 （不可以对其他窗口进行操作）
    // 非模态对话框 （可以对其他窗口操作）

    //QDialog dlg(this);//建立在栈上，对话框一闪而过
    //dlg.resize(200,100);
    //dlg.exec();//阻塞，防止对话框一闪而过
    //qDebug()<<"弹出对话框！";

        //非模块对话框

//        QDialog *dlg2 = new QDialog(this);//建立在堆中
//        dlg2->resize(200,200);
//        dlg2->show();
//        dlg2->setAttribute(Qt::WA_DeleteOnClose);//需要自己释放内存
//        qDebug()<< "对话框已弹出!";

        //使用标准对话框QMessageBox
        //错误对话框
        //QMessageBox::critical(this,"错误","critical");
        //信息对话框
        //QMessageBox::information(this,"信息","Information");
        //询问对话框
        //参数：父亲，标题，信息，按键作用，默认选中按键
//        if(QMessageBox::Save == QMessageBox::question(this,"询问","Question",QMessageBox::Save | QMessageBox::Cancel, QMessageBox::Save))
//        {
//            qDebug()<<"点击的保存!";
//        }
//        else
//        {
//           qDebug()<< "点击的是取消";
//        }
        //警告对话框
//        QMessageBox::warning(this,"警告","warning!",QMessageBox::Ok | QMessageBox::Cancel);;
//        //选择对话框
//        QColor color = QColorDialog::getColor(QColor(255,0,0));
//        //显示三原色的值
//        qDebug()<<color.red()<<color.green()<<color.blue();

        //文件对话框   文件路径格式为双斜杠
        QString path = QFileDialog::getOpenFileName(this,"打开文件","C:\\Users\\上善若水\Desktop","(*.txt *.png)");
        qDebug()<<path;






    });
}

MainWindow::~MainWindow()
{
    delete ui;
}
