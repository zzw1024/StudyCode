#include "samallwidget.h"
#include "ui_samallwidget.h"

samallWidget::samallWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::samallWidget)
{
    ui->setupUi(this);

    //设置翻页与条码同步变动
    void(QSpinBox:: *signal)(int) = &QSpinBox::valueChanged;
    connect(ui->pageBtn,signal,ui->longBtn,&QSlider::setValue);
    connect(ui->longBtn,&QSlider::valueChanged,ui->pageBtn,&QSpinBox::setValue);
}

void samallWidget::setValue(int v)
{
    ui->pageBtn->setValue(v);
}
int samallWidget::getValue()
{
    return ui->pageBtn->value();
}

samallWidget::~samallWidget()
{
    delete ui;
}
