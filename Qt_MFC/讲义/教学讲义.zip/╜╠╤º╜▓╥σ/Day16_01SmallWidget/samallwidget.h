#ifndef SAMALLWIDGET_H
#define SAMALLWIDGET_H

#include <QWidget>

namespace Ui {
class samallWidget;
}

class samallWidget : public QWidget
{
    Q_OBJECT

public:
    explicit samallWidget(QWidget *parent = 0);
    ~samallWidget();

    void setValue(int v);

    int getValue();

private:
    Ui::samallWidget *ui;
};

#endif // SAMALLWIDGET_H
