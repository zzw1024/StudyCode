#include "widget.h"
#include "ui_widget.h"
#include <QDebug>

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);

    connect(ui->setBtn,&QPushButton::clicked,[=](){
        ui->widget->setValue(50);
    });

    connect(ui->getBtn,&QPushButton::clicked,[=](){
        qDebug() << "当前值为:" << ui->widget->getValue();
    });

}

Widget::~Widget()
{
    delete ui;
}
