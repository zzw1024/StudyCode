#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>

namespace Ui {
class Widget;
}

class Widget : public QWidget
{
    Q_OBJECT

public:
    explicit Widget(QWidget *parent = 0);
    ~Widget();

private:
    Ui::Widget *ui;

    //定时器事件
    void timerEvent(QTimerEvent *event);

    //定时器标识号，即为定时器的时间间隔的Id标识
    int id1;
    int id2;

    //事件过滤器的事件
    bool eventFilter(QObject *watched, QEvent *event);
};

#endif // WIDGET_H
