#include "widget.h"
#include "ui_widget.h"
#include <QPainter>

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
    posX = 10;
    connect(ui->pushButton,&QPushButton::clicked,[=](){
        posX+=10;
        update();

    });
}

void Widget::paintEvent(QPaintEvent *event)
{
    //����һ������
    QPainter painter(this);

    painter.drawPixmap(posX,100,QPixmap(":/Image/OnePiece.png"));

//    //move the painter
//    painter.drawRect(20,20,40,40);
//    //save the statuse
//    painter.save();
//    painter.translate(100,0);//the start point move 100
//    //get the statuse
//    painter.restore();
//    painter.drawRect(20,20,40,40);

//    //high set

//    painter.drawEllipse(QPoint(50,50),45,45);
//    //���ÿ���� Ч�ʵ�
//    painter.setRenderHint(QPainter::Antialiasing);
//    painter.drawEllipse(QPoint(150,50),45,45);


//    //���û�����ɫ
//    QPen pen(QColor(255,0,0));
//    //set the width
//    pen.setWidth(5);
//    //set the style of the pen
//    pen.setStyle(Qt::DashDotLine);
//    //fill the closed figure
//    QBrush brush(Qt::green);
//    brush.setStyle(Qt::Dense5Pattern);
//    painter.setBrush(brush);

//    //use this pen
//    painter.setPen(pen);

//    //����
//    painter.drawLine(0,0,100,100);
//    //������
//    painter.drawRect(5,5,50,50);
//    //��Բ���˺���Ϊ��Բ��
//    painter.drawEllipse(100,100,50,50);

//    QPen pen2(QColor(0,0,0));
//    //use this pen
//    painter.setPen(pen2);
//    //д����
//    painter.drawText(200,200,u8"��ã�");

}

Widget::~Widget()
{
    delete ui;
}
