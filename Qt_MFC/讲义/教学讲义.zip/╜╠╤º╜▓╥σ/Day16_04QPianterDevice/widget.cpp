#include "widget.h"
#include "ui_widget.h"
#include <QPainter>
#include <QPicture>

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);

    //QPixmap做绘图设备  对不同平台显示做了优化
//    QPixmap pix(250,250);
//    pix.fill(Qt::white);
//    QPainter painter(&pix);
//    painter.setPen(QPen(Qt::green));
//    painter.drawEllipse(QPoint(100,100),50,50);
//    pix.save("F:\\pix.png");


    //QImage 做绘图设备  对象素级访问进行了优化
//    QImage image(250,250,QImage::Format_RGB32);
//    image.fill(Qt::white);
//    QPainter painter(&image);
//    painter.setPen(QPen(Qt::yellow));
//    painter.drawEllipse(QPoint(100,100),50,50);
//    image.save("F:\\image.png");

    //QPicture 绘图设备
//    QPicture picture;
//    QPainter painter;
//    painter.begin(&picture);

//    painter.setPen(QPen(Qt::blue));
//    painter.drawEllipse(QPoint(100,100),50,50);
//    painter.end();
//    picture.save("F:\\picture.zzw");//无法正常打开
    //使用代码打开
    //一般Qpicture绘图设备是用来保留图片的，并不是用来展示图片的
}

void Widget::paintEvent(QPaintEvent *event)
{
    //重现QPicture中的图片
//    QPicture picture;
//    picture.load("F:\\picture.zzw");
//    QPainter painter(this);
//    painter.drawPicture(0,0,picture);

    //使用QImage来改变图像的像素点
    QImage image;
    image.load(":/Image/Luffy.png");
    for(int i = 50 ; i < 100;i++)
    {
        for(int j = 50 ; j < 100 ;j ++)
        {
            QRgb value = qRgb(255,0,0);
            //设置像素点
            image.setPixel(i,j,value);
        }
    }

    QPainter painter(this);
    painter.drawImage(QPoint(100,100),image);


}

Widget::~Widget()
{
    delete ui;
}
