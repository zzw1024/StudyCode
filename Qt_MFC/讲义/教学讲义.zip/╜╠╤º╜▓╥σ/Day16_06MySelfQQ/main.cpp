#include "widget.h"
#include "dialoglist.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
//    Widget w;
//    w.show();
    DialogList d;//显示小窗口
    d.show();

    return a.exec();
}
