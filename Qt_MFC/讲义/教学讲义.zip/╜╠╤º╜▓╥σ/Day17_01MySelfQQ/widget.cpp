#include "widget.h"
#include "ui_widget.h"

Widget::Widget(QWidget *parent, QString name) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
}

void Widget::closeEvent(QCloseEvent *event)
{
    emit this->closeWidget();
    //sndMsg(UsrLeft);
//    //断开套接字
//    udpScoketclose();

}
Widget::~Widget()
{
    delete ui;
}
