#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>

namespace Ui {
class Widget;
}

class Widget : public QWidget
{
    Q_OBJECT

public:
    explicit Widget(QWidget *parent, QString name);
    ~Widget();

private:
    Ui::Widget *ui;

signals:
    void closeWidget();
public:
    void closeEvent(QCloseEvent *event);

};

#endif // WIDGET_H
