#include "udp.h"
#include "upd2.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    Udp w;
    w.show();

    upd2 u;
    u.show();

    return a.exec();
}
