#include "udp.h"
#include "ui_udp.h"

Udp::Udp(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Udp)
{
    ui->setupUi(this);
}

Udp::~Udp()
{
    delete ui;
}
