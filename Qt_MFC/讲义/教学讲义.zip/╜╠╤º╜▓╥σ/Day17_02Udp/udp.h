#ifndef UDP_H
#define UDP_H

#include <QWidget>

//#include <QUdpSocket>



namespace Ui {
class Udp;
}

class Udp : public QWidget
{
    Q_OBJECT

public:
    explicit Udp(QWidget *parent = 0);
    ~Udp();

private:
    Ui::Udp *ui;

//public:
    //�׽���
    //QUdpSocket *udp;

};

#endif // UDP_H
