#include "upd2.h"
#include "ui_upd2.h"

upd2::upd2(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::upd2)
{
    ui->setupUi(this);

    //初始化属性
    ui->MyPort->setText("9999");
    ui->ToPort->setText("8888");
    ui->ToIP->setText("127.0.0.1");

    //创建套接字
    udp = new QUdpSocket(this);

    //绑定自身的端口号
    udp->bind(ui->MyPort->text().toInt());

    //点击发送将文字发送出去
    connect(ui->pushButton,&QPushButton::clicked,[=](){
        //书写报文 参数  内容  对方IP  对方端口
        udp->writeDatagram(ui->textEdit->toPlainText().toUtf8(),QHostAddress(ui->ToIP->text()),ui->ToPort->text().toInt());

        //在聊天记录窗口进行记录
        ui->textBrowser->append("My:"+ui->textEdit->toPlainText());

        //清空输入框
        ui->textEdit->clear();
    });

    //接受数据
    connect(udp,&QUdpSocket::readyRead,[=](){
        //获取报文长度
        qint64 long = udp->pendingDatagramSize();
        QByteArray array = QByteArray(size,0);
        //读取报文
        udp->readDatagram(array.data(),size);
        //同步数据
        ui->textBrowser->append("You:"+array);

    });
}

upd2::~upd2()
{
    delete ui;
}
