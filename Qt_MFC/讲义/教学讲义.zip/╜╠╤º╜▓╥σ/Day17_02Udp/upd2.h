#ifndef UPD2_H
#define UPD2_H

#include <QWidget>
//#include <QUdpSocket>

namespace Ui {
class upd2;
}

class upd2 : public QWidget
{
    Q_OBJECT

public:
    explicit upd2(QWidget *parent = 0);
    ~upd2();

private:
    Ui::upd2 *ui;

public:
    //QUdpSocket *udp;
};

#endif // UPD2_H
