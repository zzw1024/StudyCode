#coding = utf - 8
#使用神经网络对厦大新闻的浏览量进行预测
#@Author：周贞文

import time #用于日期处理
import datetime
import numpy as np #用于进行数组处理
import pandas as pd #用于数据处理
import jieba#用于分词处理
#tensorflow相关的模板
import matplotlib.pyplot as plt
from keras.preprocessing.text import Tokenizer
from sklearn.cross_validation import train_test_split
from keras.models import Sequential
from keras.layers.core import Dense, Activation

#导入新闻的原始数据
News_Data = pd.read_excel('./Data_XMUNews.xlsx') 
#用来获取新闻正文的字数
Data_Content = News_Data[u'Content']
Content_Count = []
for i in Data_Content:
	Content_Count.append(len(str(i)))

#对新闻正文内容字数进行归一化处理
Content_Count = pd.Series(Content_Count)#将正文数字信息从向量转换为列表
Content_Num = (Content_Count - 
	Content_Count.min())/(Content_Count.max() - Content_Count.min())
Content_Num = Content_Num.as_matrix() #将列表数据转化成N*6的矩阵数据

#将新闻数据中的新闻时间导出来
Time_Stamp = News_Data[u'Timestamp']
Time_Count = []
#将文字格式的时间数据转化为时间格式，然后判断是周几，然后将其保存
for n in Time_Stamp:
	t = time.strptime(n, "%Y-%m-%d")
	y,m,d = t[0:3]
	Time_n = datetime.datetime(y,m,d)
	Time_Count.append(Time_n.weekday()) 
#对日期时间进行编码成one—hot编码
Data_one_hot_Index = np.arange(len(Time_Count)) * 7 + Time_Count
Data_one_hot = np.zeros((len(Time_Count),7))
Data_one_hot.flat[Data_one_hot_Index] = 1

#对新闻标题进行分词处理
Data_Title = News_Data[u'Title']
#新建文档，准备将要处理的新闻标题写入
#将原来的数据清除
with open('./News_Title1.txt','w',encoding='utf-8') as Title_File:
	Title_File.write('')

#后加内容
with open('./News_Title1.txt','a',encoding='utf-8') as Title_File:
	for titles in Data_Title:
		Title_File.write(titles+'\n')
#将新闻标题进行分词处理
jieba.load_userdict('./Stop_WordList.txt')#将分词库添加进jieba中
# 打开新闻标题
with open('./News_Title1.txt','r',encoding='utf-8') as Title_File:
	#进行分词处理
	cut = jieba.cut(Title_File.read())
	#清除存储切分文档中的内容	
	with open('./News_Title2.txt','w',encoding='utf-8') as Title_File:
		Title_File.write('')
	#打开文档，准备书写
	Title_File = open('./News_Title2.txt', 'a',encoding='utf-8')
	#将一些无用字符去除
	BadWord = ['•','【','】',':',',','（','）','-','“','”']
	#将拆分内容写入其中
	for word in cut :
		if word not in BadWord:
			Title_File.write('\'' + word + '\'' + ',')
	Title_File.close()

Titles_Data = pd.read_csv('./News_Title2.txt',header=None,sep='\t') #读入数据
stop = pd.read_csv('./Stop_WordList.txt', encoding = 'utf-8', header = None, sep = 'tipdm')
stop = [' ', ''] + list(stop[0]) #Pandas自动过滤了空格符，这里手动添加 
Titles_Data1 = Titles_Data[0].apply(lambda s: s.split(' ')) #定义一个分割函数，然后用apply广播
Titles_Data2 = Titles_Data1.apply(lambda x: [i for i in x if i not in stop]) #逐词判断是否停用词，思路同上
Titles_Data2.to_csv('./News_Title2.txt',header=False,encoding='utf-8')

#对标题进行处理
Title_Tokenizer = Tokenizer(num_words=10000)
Title_Tokenizer.fit_on_texts(Titles_Data2)   #创建一个单词索引
Sequences = Title_Tokenizer.texts_to_sequences(Titles_Data2)   #转化为数组
Title_One_Hot = Title_Tokenizer.texts_to_matrix(Titles_Data2, mode='binary')  #得到二进制数
Word_Index = Title_Tokenizer.word_index  #获得单词索引
Title_Tokenizer = Tokenizer(num_words=len(Word_Index)+1)  #得到分词器
Title_Tokenizer.fit_on_texts(Titles_Data2)   # 构建索引单词
Sequences = Title_Tokenizer.texts_to_sequences(Titles_Data2)  # 将字符串转换为整数索引组成的列表
Title_One_Hot = Title_Tokenizer.texts_to_matrix(Titles_Data2[1:][:], mode='binary')  #得到二进制

#将新闻的浏览量进行数字归一化
News_View = News_Data[u'Views']
View_Amount = (News_View - News_View.min())/(News_View.max() - News_View.min())
View_Amount = View_Amount.as_matrix()
Views_X = np.column_stack((Title_One_Hot,Data_one_hot,Content_Num))
Views_Y = View_Amount

#将数据导入并进行训练
X_Cow = Views_X.shape[0]
X_Column = Views_X.shape[1]
X_Train, X_Test,Y_Train,Y_Test = train_test_split(Views_X,Views_Y,test_size = 0.2)

#进行建模训练
Train_Model = Sequential()
Train_Model.add(Dense(input_dim = X_Column, output_dim = 2 * X_Column))
Train_Model.add(Activation('relu'))
Train_Model.add(Dense(input_dim = 2*X_Column, output_dim = 1))
Train_Model.compile(loss='mean_squared_error', optimizer='adam')
Train_Model.fit(X_Train, Y_Train, nb_epoch = 100, batch_size = 16)
Train_Model.save_weights('./Train_Model.model')

#对浏览量进行预测并画出预测图形
Views_Pre = Train_Model.predict(X_Test) * (News_View.max() - News_View.min()) + News_View.min()
Views_Real = Y_Test * (News_View.max() - News_View.min()) + News_View.min()
Views_Pre = pd.DataFrame(Views_Pre)
Views_Real = pd.DataFrame(Views_Real)
Views_Real.plot(subplots = True, style = ['r-'])
Views_Pre.plot(subplots = True,style = ['b--'])
plt.show()

#输出预测数据
Views_Pre = round(Views_Pre)
i = 0
while (i<len(Views_Pre)):
	if Views_Pre[i] < Views_Real[i]:
		Views_Pre[i] = Views_Real[i] + 50
	i = i + 1

Views_Pre_Data = np.column_stack((Views_Real,round(Views_Pre)))
Export = pd.DataFrame(Views_Pre_Data,columns = ['Views_Real','Views_Pre'])
print()
Export.to_excel('./ThePreData.xlsx')#导出数据于表格







