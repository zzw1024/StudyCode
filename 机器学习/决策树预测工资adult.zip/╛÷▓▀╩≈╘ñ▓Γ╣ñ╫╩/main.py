#-*- coding: utf-8 -*-
# 本程序是使用决策树来预测工资
# @author：周贞文

import graphviz
import pandas as pd
import numpy as np
from sklearn import tree
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import LabelEncoder
 
names=['Age', 'WorkClass','Fnlwgt','Education','EducationNum','MaritalStatus','Occupation','Relationship',
		'Race','Sex','CapitalGain','CapitalLoss','HoursPerWeek','NativeCountry','Salary']#数据标题

data_train = pd.read_csv('./adult.data', header=None, names=names) #训练参数 
data_test = pd.read_csv('./adult.test', header=None, names=names)  #测试参数

#删除空值‘？’
data_train = data_train.replace(to_replace = ' ?', value = np.nan)
data_train = data_train.dropna()
data_test = data_test.replace(to_replace = ' ?', value = np.nan)
data_test = data_test.dropna()

#自动转换非数字列为数字
for name in names:
    data_train[name]=LabelEncoder().fit_transform(data_train[name]) 
    data_test[name]=LabelEncoder().fit_transform(data_test[name]) 

x_train = data_train[data_train.columns[:-1]]
y_train = data_train[data_train.columns[-1]]   
x_test = data_test[data_test.columns[:-1]]
y_test = data_test[data_test.columns[-1]]

# x_train, x_valid, y_train, y_valid = train_test_split(x, y, test_size=0.3, random_state=0)
#决策树模型
DT = DecisionTreeClassifier(criterion='gini',max_depth=10,min_samples_split=5)
DT.fit(x_train,y_train)
y_pre = DT.predict(x_test)#测试数据集
rate = accuracy_score(y_pre, y_test)#计算准确率
print(rate)

#以下为三种模型的预测DT,RF,LR
# DT = DecisionTreeClassifier(criterion='gini',max_depth=10,min_samples_split=5)
# RF = RandomForestClassifier(criterion='gini', max_depth=10, min_samples_split=5,n_estimators=20)
# LR= LogisticRegression()
# models=[DT,RF,LR]
# for model in models:
#     model.fit(x_train,y_train)
#     y_pre=model.predict(x_valid)
#     print('验证集准确率：', accuracy_score(y_pre, y_valid))

#可视化
clf_tree = tree.DecisionTreeClassifier(criterion='gini',max_depth=10,min_samples_split=5)
clf_tree.fit(x_train, y_train)
y_tree = clf_tree.predict(x_test)
feature = names[:-1]
dot_data = tree.export_graphviz(clf_tree, out_file='./tree.dot', feature_names = feature, class_names=['1', '2', '3'],
								filled=True, rounded=True, special_characters=True)  
graph = graphviz.Source(dot_data)

# 执行完以后，可以生成一个叫 ‘tree.dot’ 的 dot 文件。然后在终端命令行中输入：

# dot -Tpng tree.dot -o loan_tree.png #png
# dot -Tpdf tree.dot -o loan_tree.pdf #pdf












# import pandas as pd
# import numpy as np
# import sklearn
# from sklearn.cross_validation import train_test_split
# from sklearn.feature_extraction import DictVectorizer
# from sklearn.tree import DecisionTreeClassifier
# from sklearn.metrics import classification_report
# from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
# data1 = pd.read_csv('./adult.data',encoding = 'gbk', header = None, 
# 		names=['Age', 'WorkClass','Fnlwgt','Education','EducationNum','MaritalStatus','Occupation','Relationship',
# 		'Race','Sex','CapitalGain','CapitalLoss','HoursPerWeek','NativeCountry','Salary'])
# data2 = pd.read_csv('./adult.test',encoding = 'gbk', header = None, 
# 		names=['Age', 'WorkClass','Fnlwgt','Education','EducationNum','MaritalStatus','Occupation','Relationship',
# 		'Race','Sex','CapitalGain','CapitalLoss','HoursPerWeek','NativeCountry','Salary'])
# data1 = data1.replace(to_replace = ' ?', value = np.nan)
# data1 = data1.dropna()
# data2 = data2.replace(to_replace = ' ?', value = np.nan)
# data2 = data2.dropna()
# print(data2)

# #选取一些特征作为我们划分的依据
# x_train = data1[['Age', 'WorkClass','Fnlwgt','Education','EducationNum','MaritalStatus','Occupation','Relationship',
# 		'Race','Sex','CapitalGain','CapitalLoss','HoursPerWeek','NativeCountry']]
# y_train = data1['Salary']

# x_test = data2[['Age', 'WorkClass','Fnlwgt','Education','EducationNum','MaritalStatus','Occupation','Relationship',
# 		'Race','Sex','CapitalGain','CapitalLoss','HoursPerWeek','NativeCountry']]
# y_test = data2['Salary']
# # 填充缺失值
# # x['age'].fillna(x['age'].mean(), inplace=True)
 
# # x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.25)
 
# dt = DictVectorizer(sparse=False)
 
# # print(x_train.to_dict(orient="record"))#对训练数据的特征进行提取
 
# # 按行，样本名字为键，列名也为键，[{"1":1,"2":2,"3":3}]
# x_train = dt.fit_transform(x_train.to_dict(orient="record"))
 
# x_test = dt.fit_transform(x_test.to_dict(orient="record"))
 
# # 使用决策树
# dtc = DecisionTreeClassifier()
 
# dtc.fit(x_train, y_train)
 
# dt_predict = dtc.predict(x_test)
 
# print(dtc.score(x_test, y_test))
 
# print(classification_report(y_test, dt_predict, target_names=["died", "survived"]))
 
















# # 使用随机森林
 
# rfc = RandomForestClassifier()
 
# rfc.fit(x_train, y_train)
 
# rfc_y_predict = rfc.predict(x_test)
 
# print(rfc.score(x_test, y_test))
 
# print(classification_report(y_test, rfc_y_predict, target_names=["died", "survived"]))


