# -*- coding: utf-8 -*-
"""
Created on Sun May 26 16:48:55 2019

@author: 上善若水
"

a =10

        
        