from sklearn.tree import DecisionTreeClassifier
import numpy as np 
import pandas as pd 
from sklearn.externals import joblib
from sklearn.feature_extraction import DictVectorizer
from sklearn.metrics import roc_curve
import matplotlib.pyplot as plt 
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import GridSearchCV

datafile = 'adult.data'
testfile = 'adult.test'
outfile = 'dicision_tree.pkl'
column = ['age','workclass','fnlwgt','education','education_num','marital_status','occupation','relationship','race','sex','capital_gain','capital_loss','hour_per_week','native_country','income']
x_column_feature = ['age','workclass','fnlwgt','education','education_num','marital_status','occupation','sex','capital_gain','capital_loss','hour_per_week','native_country']
dis_feature = ['age','workclass','education','occupation','sex','hour_per_week','native_country']

def main():
	#从文件CSV中读取数据，使用pd.read_csv('目录'，header = None,names = column,)
	data = pd.read_csv(datafile,header = None,names = column,encoding = 'utf8')
	test_data = pd.read_csv(testfile,header = None,names = column,encoding = 'utf8')


	#看看有多少缺失值,如果缺失值少则直接去掉缺失值所在的行
	for feature in x_column_feature:
		nannum = len(data) - data[feature].count()
		nannum_test = len(test_data) - test_data[feature].count()
		print(nannum)
		print(nannum_test)

	#去除dataframe中所含缺失值的行
	data.dropna(axis = 0,how = 'any',inplace = True)
	test_data.dropna(axis = 0,how = 'any',inplace = True)

	#读取有用特征还有label，使用data[['age','sex']]方法读取多列
	x_train = data[x_column_feature]
	y_train = data['income']
	x_test = test_data[x_column_feature]
	y_test = test_data['income']


	#将dataframe转换成numpy，方便label中字符串变量转换成int型
	y_test = y_test.as_matrix()
	y_train = y_train.as_matrix()

	#进行特征工程处理，将非int的feature转换成one-hot编码
	dict = DictVectorizer(sparse = False)

	#进行转换前，必须把x_train转换成字典，所用方法为x_train.to_dict(orient = 'records')
	x_train = dict.fit_transform(x_train.to_dict(orient = 'records'))


	print(dict.get_feature_names())

	x_test = dict.transform(x_test.to_dict(orient = 'records'))

	k = 0
	for y in y_train:
		if '>' in y:
			y_train[k] = 1
		else:
			y_train[k] = 0
		k += 1

	k = 0
	for y in y_test:
		if '>' in y:
			y_test[k] = 1
		else:
			y_test[k] = 0
		k += 1

	tree = DecisionTreeClassifier(max_depth = 5)
	tree.fit(x_train,y_train.astype('int')).predict_proba(x_test)

	print('训练集的准确率为:',tree.score(x_train,y_train.astype('int')))
	print('预测的准确率:',tree.score(x_test,y_test.astype('int')))

	# y_test = np.array(y_test)
	# y_predict = np.array(y_predict[:,1])




	# rf = RandomForestClassifier()

	# param = {'n_estimators':[120,200,300,500,800,1200],'max_depth':[5,8,15,25,30]}
	# gc = GridSearchCV(rf,param_grid = param,cv = 2)

	# gc.fit(x_train,y_train.astype('int'))

	# print('准确率：',gc.score(x_test,y_test.astype('int')))

	# print('选择的参数模型是：',gc.best_params_)
	# fpr,tpr,thresholds = roc_curve(y_test.astype('int'),y_predict,pos_label = 1)
	# plt.plot(fpr,tpr,linewidth = 2,label = 'ROC of CART')

	# plt.xlabel('False Positive Rate')
	# plt.ylabel('True Positive Rate')

	# plt.ylim(0,1.05)
	# plt.xlim(0,1.05)

	# plt.legend(loc = 4)
	# plt.show()
	return None
if __name__ == '__main__':
	main()