import sys
import pygame
from pygame.sprite import Group

from settings import Settings
from ship import Ship
import game_functions as gf

def run_game():
	pygam.display.set_caption("Alien Invastion")
	#initialtion the pygame、set、screen
	pygame.init()
	ai_settings = Settings()
	screen = pygame.display.set_mode((ai_settings.screen_width,ai_settings.screen_height))
	
	#creat a ship
	ship = Ship(ai_settings, screen)
	#creat a bullet
	bullets = Group()
	#creat the alien
	aliens = Group()

	gf.creat_fleet(ai_settings,screen,ship,aliens)

	stats = GameStats(ai_settings)

	#begin the major cycle of game
	while True:
		gf.check_events(ai_settings, screen, ship, bullets)
		ship.update()
		gf.update_bullets(ai_settings, screen, ship, aliens, bullets)
		gf.updata_aliens(ai_settings, stats, screen, ship, aliens, bullets)
		gf.updata_screen(ai_settings,screen,ship,aliens,bullets)

		
run_game()