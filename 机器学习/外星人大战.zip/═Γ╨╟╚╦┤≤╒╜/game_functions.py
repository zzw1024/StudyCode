import sys
import pygame

from bullet import Bullet
from alien import Alien
from time import sleep

def check_keydown_events(event,ai_settings,screen, ship,bullets):
	if event.key == pygame.K_RIGHT:
        #turn right
		ship.moving_right = True

	elif event.key == pygame.K_LEFT:
		#turn left
		ship.moving_left = True

	elif event.key == pygame.K_SPACE:
		fire_bullet(ai_settings,screen,ship,bullets)	

	elif event.key == pygame.K_ESCAPE:
		sys.exit()

	# elif event.key == pygame.K_UP:
	# 	#go up
	# 	ship.moving_up = True

	# elif event.key == pygame.K_DOWN:
	# 	#go down
	# 	ship.moving_down = True

def check_keyup_events(event,ship):
	if event.key == pygame.K_RIGHT:
		ship.moving_right = False

	elif event.key == pygame.K_LEFT:
		ship.moving_left = False

	# elif event.key == pygame.K_UP:
	# 	ship.moving_up = False

	# elif event.key == pygame.K_DOWN:
	# 	ship.moving_down = False	

def check_events(ai_settings,screen,ship,bullets):
	#response the event of keybord and mouse
	for event in pygame.event.get():
			if event.type == pygame.QUIT:
				sys.exit()

			elif event.type == pygame.KEYDOWN:
				check_keydown_events(event,ai_settings, screen, ship, bullets)

			elif event.type == pygame.KEYUP:
				check_keyup_events(event,ship)

def fire_bullet(ai_settings,screen,ship,bullets):
	#creat the bullets
	if len(bullets) < ai_settings.bullet_allowed:
		new_bullet = Bullet(ai_settings,screen,ship)
		bullets.add(new_bullet)	

def get_number_aliens_x(ai_settings,alien_width):
	available_space_x = ai_settings.screen_width - 2 * alien_width
	number_aliens_x = int(available_space_x / (2 * alien_width))
	return number_aliens_x

def get_number_rows(ai_settings,ship_height,alien_height):
	available_space_y = (ai_settings.screen_height - ship_height - 3*alien_height)
	number_rows = int(available_space_y / ( 2 * alien_height))
	return number_rows

def creat_alien(ai_settings,screen,aliens,alien_number,row_number):
	alien = Alien(ai_settings,screen)
	alien_width = alien.rect.width
	alien.x = alien_width + 2 * alien_width * alien_number
	alien.rect.x = alien.x
	alien.rect.y = alien.rect.height + 2 * alien.rect.height * row_number
	aliens.add(alien)

def creat_fleet(ai_settings,screen,ship,aliens):
	#creat the aliens
	alien = Alien(ai_settings,screen)
	number_aliens_x = get_number_aliens_x(ai_settings,alien.rect.width)
	number_rows = get_number_rows(ai_settings,ship.rect.height,alien.rect.height)

	for row_number in range(number_rows):
		for alien_number in range(number_aliens_x):
			creat_alien(ai_settings,screen,aliens,alien_number,row_number)

def updata_screen(ai_settings,screen,ship, aliens,bullets):
	#updata the image of screen and exchange to the new screen
	screen.fill(ai_settings.bg_color)
	for bullets in bullets.sprites():
		bullets.draw_bullet()
	ship.blitme()
	aliens.draw(screen)
	#display the screen
	pygame.display.flip()

def update_bullets(ai_settings, screen, ship, aliens, bullets):
	#update the local of bullets
	bullets.update()
	#delete the disappear bullet
	for bullet in bullets.copy():#不应对原bullet列表进行删除，应该对其副本进行处理
		if bullet.rect.bottom <= 0:
			bullets.remove(bullet)

	check_bullet_alien_collisons(ai_settings, screen, ship, aliens, bullets)

def check_bullet_alien_collisons(ai_settings, screen, ship, aliens, bullets)
	#check whether any aliens shutted, if yes, delete the bullets and liens
	collisions = pygame.sprite.groupcollide(bullets, aliens, True, True)

	if len(aliens) == 0:
		# delete the all bullets, and creat some new aliens
		bullets.empty()
		creat_fleet(ai_settings, screen, ship, aliens)

def updata_alens(ai_settings aliens):
	# updata the local of aliens
	aliens.updata()

def check_fleet_edges(ai_settings,aliens):
	#if the aliens get at the screen edge, make the measure
	for alien in aliens.sprites():
		if alien.check_edges():
			change_fleet_direction(ai_settings,aliens)
			break

def change_fleet_direction(ai_settings, aliens):
	#make the aliens move down, and change their direction
	for alien in aliens.aprites():
		aliens.rect.y += ai_settings.fleet_drop_speed
	ai_settings.change_fleet_direction *= -1

def updata_aliens(ai_settings, ship, aliens):
	#updata the local of the aliens
	check_fleet_edges(ai_settings,aliens)
	aliens.update()

	#check is there any liens touch the ship
	if pygame.sprite.spritecollideany(ship, aliens):
		print("Ship hit!!!")
		print("Game over!!!")

def ship_hit(ai_settings, stats, screen, ship, aliens, bullets):
	#influce the ship which touched by aliens
	#make the ship_left decline 
	stats.ships_left -= 1

	#clear alien_list and bullet_list
	aliens.empty()
	bullets.empty()

	#creat some new aliens and make the ship at the bumdn of screen
	creat_fleet(ai_settings, screen, ship, alines)
	ship.center_ship()

	#stop
	sleep(0.5)





		

	
