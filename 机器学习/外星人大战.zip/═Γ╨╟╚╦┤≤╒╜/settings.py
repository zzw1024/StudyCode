class Settings():
	#save the class all of the set 

	def __init__(self):
		#set of screen
		self.screen_width = 800
		self.screen_height = 600
		self.bg_color = (230,230,230)

		#set of ship
		self.ship_speed_factor = 1.5
		self.ship_limit = 3
		#set of aline
		self.aline_speed_factor = 1
		self.fleet_drop_speed = 10
		# move 1:right;2:left
		self.fleet_direction = 1 

		#set of buttle
		self.bullet_speed_factor  = 3
		self.bullet_width = 3
		self.bullet_height = 15
		self.bullet_color = (60,60,60)
		self.bullet_allowed = 100000
