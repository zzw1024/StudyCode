# -*- coding: utf-8 -*-
"""
Created on Sun May 26 10:09:28 2019

@author: 上善若水
"""

import graphviz
import numpy as np
import pandas as pd
import seaborn as sns
import copy
import matplotlib.pyplot as plt
from sklearn.externals.six import StringIO
import pydotplus


#首先引入需要的库和函数
from sklearn import tree
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction import DictVectorizer
from sklearn.metrics import accuracy_score


#PassengerId
#Pclass
#Name
#Sex
#Age
#sibSp
#Parch
#Ticket
#Fare
#Cabin
#Embarked


def Comm(train, test, result):
        #年龄特征分类
        train['Age']=train['Age'].map(lambda x: 'child' if x<12 else 'youth' 
                             if x<30 else 'adlut' if x<60 else 'old' 
                             if x<75 else 'tooold' if x>=75 else 'null')        
        
        train['SibSp']=train['SibSp'].map(lambda x: 'small' if x<1 else 'middle' 
                                    if x<3 else 'large')
        
        train['Parch']=train['Parch'].map(lambda x: 'small' if x<1 else 'middle' 
                                     if x<4 else 'large')             
            
        train['Fare']=train['Fare'].map(lambda x:np.log(x+1))
        train['Fare']=train['Fare'].map(lambda x: 'poor' if x<2.5 else 'rich')
        
        train['Cabin']=train['Cabin'].map(lambda x:'yes' if type(x)==str else 'no')
               
        #删掉含有缺损值的样本
        train.dropna(axis=0,inplace=True)
            
        
        #删除认为不重要的特征5
        #将训练数据分成标记和特征两部分        
        features= train.drop(['Survived','PassengerId','Name','Ticket'],axis=1)  
        
        ##对所有特征实现one-hot 的编码
        features = pd.get_dummies(features)
        
        #处理测试数据
        #对'Age','SibSp'，'Parch'特征进行分段分类
        test['Age']=test['Age'].map(lambda x: 'child' if x<12 else 'youth' if x<30 else 'adlut' if x<60 else 'old' if x<75 else 'tooold' if x>=75 else 'null')
        test['SibSp']=test['SibSp'].map(lambda x: 'small' if x<1 else 'middle' if x<3 else 'large')
        test['Parch']=test['Parch'].map(lambda x: 'small' if x<1 else 'middle' if x<4 else 'large')
        #均值补齐'Fare'特征值并作对数转换和分类
        test.Fare.fillna(test['Fare'].mean(), inplace=True)
        test['Fare']=test['Fare'].map(lambda x:np.log(x+1))
        test['Fare']=test['Fare'].map(lambda x: 'poor' if x<2.5 else 'rich')
        #按'Cabin'是否缺损分类
        test['Cabin']=test['Cabin'].map(lambda x:'yes' if type(x)==str else 'no')
        
        #删除不需要的特征
        test=test.drop(['PassengerId','Name','Ticket'],axis=1)
        
        #进行one-hot编码
        test=pd.get_dummies(test)
              
        #训练数据
        x_train=features
        y_train=train['Survived']
        #测试数据
        x_test=test
        
        return x_train, y_train, x_test, result
        

#数据处理 
#'PassengerId',‘Survived’,‘Pclass’,'Name', 'Sex','Age','SibSp','Parch','Ticket','Fare','Cabin','Embarked'
#只使用‘Pclass’,'Sex',Fare',
def Deal3(train1, test1,result1):
        train1['Fare']=train1['Fare'].map(lambda x:np.log(x+1))
        train1['Fare']=train1['Fare'].map(lambda x: 'poor' if x<2.5 else 'rich')
        train1= train1.drop(['PassengerId','Name', 'Age','SibSp','Parch',
                             'Ticket','Cabin','Embarked'],axis=1)
        train1.dropna(axis=0,inplace=True)        
        features1= train1.drop(['Survived'],axis=1)
        
        features1 = pd.get_dummies(features1)
        
        x_train1=features1
        y_train1=train1['Survived']
        
        #处理测试数据
        test1.Fare.fillna(test1['Fare'].mean(), inplace=True)
        test1['Fare']=test1['Fare'].map(lambda x:np.log(x+1))
        test1['Fare']=test1['Fare'].map(lambda x: 'poor' if x<2.5 else 'rich')       
        
        #删除不需要的特征
        test1=test1.drop(['PassengerId','Name', 'Age','SibSp','Parch',
                         'Ticket','Cabin','Embarked'], axis=1)        
        #进行one-hot编码
        test1=pd.get_dummies(test1)       
        
        #测试数据
        x_test1=test1
        
        #决策树模型
        dt = DecisionTreeClassifier()
        
        #训练
        dt.fit(x_train1,y_train1)
        
        #测试
        y_test1=dt.predict(x_test1)
        
        #计算准确率
        rate3=accuracy_score(y_test1, result1)
              
         
        #可视化
        fname = test1.columns.values.tolist()
        tree.export_graphviz(dt,out_file='./tree3.dot',feature_names=fname)
        return rate3
    


#'PassengerId',‘Survived’,‘Pclass’,'Name', 'Sex','Age','SibSp','Parch','Ticket','Fare','Cabin','Embarked'
#只使用‘Pclass’,'Sex','Age','Fare','Embarked'
def Deal5(train, test,result):
        #年龄特征分类
        train['Age']=train['Age'].map(lambda x: 'child' if x<12 else 'youth' 
                             if x<30 else 'adlut' if x<60 else 'old' 
                             if x<75 else 'tooold' if x>=75 else 'null')  
        train['Fare']=train['Fare'].map(lambda x:np.log(x+1))
        train['Fare']=train['Fare'].map(lambda x: 'poor' if x<2.5 else 'rich')
        
        train= train.drop(['PassengerId','Name','SibSp','Parch',
                             'Ticket','Cabin'],axis=1)
        train.dropna(axis=0,inplace=True)        
        features= train.drop(['Survived'],axis=1)        
        features = pd.get_dummies(features)
        
        x_train=features
        y_train=train['Survived']
        
        #处理测试数据
        #对'Age','SibSp'，'Parch'特征进行分段分类
        test['Age']=test['Age'].map(lambda x: 'child' if x<12 else 'youth' if x<30 else 'adlut' if x<60 else 'old' if x<75 else 'tooold' if x>=75 else 'null')
       #均值补齐'Fare'特征值并作对数转换和分类
        test.Fare.fillna(test['Fare'].mean(), inplace=True)
        test['Fare']=test['Fare'].map(lambda x:np.log(x+1))
        test['Fare']=test['Fare'].map(lambda x: 'poor' if x<2.5 else 'rich')
        #删除不需要的特征
        test=test.drop(['PassengerId','Name','SibSp','Parch','Ticket','Cabin'], axis=1)        
            
        #进行one-hot编码
        test=pd.get_dummies(test)
        
        #测试数据
        x_test=test
        
        #决策树模型
        dt = DecisionTreeClassifier()
        
        #训练
        dt.fit(x_train,y_train)
        
        #测试
        y_test=dt.predict(x_test)
        
        #计算准确率
        rate5=accuracy_score(y_test, result)
        return rate5


#'PassengerId',‘Survived’,‘Pclass’,'Name', 'Sex','Age','SibSp','Parch','Ticket','Fare','Cabin','Embarked'
#只使用‘Pclass’,'Sex','Age','SibSp','Parch','Fare','Embarked'
def Deal7(train, test,result):
        #年龄特征分类
        #年龄特征分类
        train['Age']=train['Age'].map(lambda x: 'child' if x<12 else 'youth' 
                             if x<30 else 'adlut' if x<60 else 'old' 
                             if x<75 else 'tooold' if x>=75 else 'null')        
        
        train['SibSp']=train['SibSp'].map(lambda x: 'small' if x<1 else 'middle' 
                                    if x<3 else 'large')
        
        train['Parch']=train['Parch'].map(lambda x: 'small' if x<1 else 'middle' 
                                     if x<4 else 'large')             
            
        train['Fare']=train['Fare'].map(lambda x:np.log(x+1))
        train['Fare']=train['Fare'].map(lambda x: 'poor' if x<2.5 else 'rich')
               
        #删掉含有缺损值的样本
        train= train.drop(['PassengerId','Name','Ticket','Cabin'],axis=1)
        train.dropna(axis=0,inplace=True)   
        
        features= train.drop(['Survived'],axis=1)        
        features = pd.get_dummies(features)
        
        x_train=features
        y_train=train['Survived']
        
        #处理测试数据
        #对'Age','SibSp'，'Parch'特征进行分段分类
        test['Age']=test['Age'].map(lambda x: 'child' if x<12 else 'youth' if x<30 else 'adlut' if x<60 else 'old' if x<75 else 'tooold' if x>=75 else 'null')
        test['SibSp']=test['SibSp'].map(lambda x: 'small' if x<1 else 'middle' if x<3 else 'large')
        test['Parch']=test['Parch'].map(lambda x: 'small' if x<1 else 'middle' if x<4 else 'large')
        #均值补齐'Fare'特征值并作对数转换和分类
        test.Fare.fillna(test['Fare'].mean(), inplace=True)
        test['Fare']=test['Fare'].map(lambda x:np.log(x+1))
        test['Fare']=test['Fare'].map(lambda x: 'poor' if x<2.5 else 'rich')
        
        #删除不需要的特征
        test=test.drop(['PassengerId','Name','Ticket','Cabin'], axis=1)  
        
        #进行one-hot编码
        test=pd.get_dummies(test)

        #测试数据
        x_test=test
                
        #决策树模型
        dt = DecisionTreeClassifier()        
        #训练
        dt.fit(x_train,y_train)        
        #测试
        y_test=dt.predict(x_test)        
        #计算准确率
        rate7=accuracy_score(y_test, result)
        return rate7


#方法2，除了使用‘Name’,'Ticket'
def Deal9(train,test, result):           
        [x_train, y_train, x_test, result]=Comm(train,test,result)
        
        dt = DecisionTreeClassifier()
        #DT = DecisionTreeClassifier(criterion='gini',max_depth=10,min_samples_split=5)
        
        #训练
        dt.fit(x_train,y_train)
        
        #测试
        y_test=dt.predict(x_test)
        
        #计算准确率
        rate9=accuracy_score(y_test, result)
#        print("方法2的准确率为：",rate)
        return rate9


#方法3，ID3
def ID3(train,test, result):           
        [x_train, y_train, x_test, result]=Comm(train,test,result)
        ID3_Rate = []
        
        for i in range(10):     
                dt = DecisionTreeClassifier(criterion="entropy",max_depth=i+3)        
                #训练
                dt.fit(x_train,y_train)
                
                #测试
                y_test=dt.predict(x_test)
                
                #计算准确率
                rate=accuracy_score(y_test, result)
                ID3_Rate.append(rate)
        
        dt = DecisionTreeClassifier(criterion="entropy")        
        #训练
        dt.fit(x_train,y_train)
        
        #测试
        y_test=dt.predict(x_test)
        
        #计算准确率
        rate=accuracy_score(y_test, result)
        ID3_Rate.append(rate)
        
        return ID3_Rate
        
        
        
#方法4，CART
def CRAT(train, test,result):
        [x_train, y_train, x_test, result]=Comm(train,test,result)       
        
        CART_Rate = []
        
        for i in range(10):     
                dt = DecisionTreeClassifier(criterion="gini",max_depth=i+3)        
                #训练
                dt.fit(x_train,y_train)
                
                #测试
                y_test=dt.predict(x_test)
                
                #计算准确率
                rate=accuracy_score(y_test, result)
                CART_Rate.append(rate)
       
        dt = DecisionTreeClassifier(criterion="gini")        
        #训练
        dt.fit(x_train,y_train)
        
        #测试
        y_test=dt.predict(x_test)
        
        #计算准确率
        rate=accuracy_score(y_test, result)
        CART_Rate.append(rate)       
        
        return CART_Rate

def Func():       
        
        #导入数据
        train = pd.read_csv('train.csv')
        test = pd.read_csv('test.csv')
        result= pd.read_csv('gender_submission.csv')
        result=result['Survived']   
        
              
        #特征个数3：
        train0= copy.copy(train)
        test0=copy.copy(test)
        r3 = Deal3(train0,test0,result)
        #特征个数5：
        train0= copy.copy(train)
        test0=copy.copy(test)
        r5 = Deal5(train0,test0,result)
        #特征个数3：
        train0= copy.copy(train)
        test0=copy.copy(test)
        r7 = Deal7(train0,test0,result)
        #特征个数3：
        train0= copy.copy(train)
        test0=copy.copy(test)
        r9 = Deal9(train0,test0,result)
        
        #IDR3
        train0= copy.copy(train)
        test0=copy.copy(test)
        ID3_Rate  =ID3(train0,test0, result)

        #CART
        train0= copy.copy(train)
        test0=copy.copy(test)
        CART_Rate  =CRAT(train0,test0, result)        
        
        #画图 
        plt.figure(1)
        plt.plot([3,5,7,9],[r3,r5,r7,r9],'r--',label='Accuracy')  
        plt.xlabel('Numbers')
        plt.ylabel('Accuracy')
        plt.legend()
        plt.show()          
        print("最优准确度为：",max([r3,r5,r7,r9]))

        

        plt.figure(2)
        plt.plot(range(1,12),ID3_Rate,'r--',label='ID3')
        plt.plot(range(1,12),CART_Rate,'b--',label='CART')  
        plt.title('Decision tree for Titanic Data')
        plt.xlabel('Depth')
        plt.ylabel('Accuracy')
        plt.legend()
        plt.show()  
        print("ID3算法的最优准确度为：",max(ID3_Rate))
        print("CART算法的最优准确度为：",max(CART_Rate))
 
        
if __name__ == '__main__':
	Func()
    








