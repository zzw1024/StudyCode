# -*- coding: utf-8 -*-
"""
Created on Sun May 26 10:09:28 2019

@author: 上善若水
"""

import graphviz
import numpy as np
import pandas as pd
import seaborn as sns
import copy


#首先引入需要的库和函数
from sklearn import tree
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction import DictVectorizer
from sklearn.metrics import accuracy_score


#PassengerId
#Pclass
#Name
#Sex
#Age
#sibSp
#Parch
#Ticket
#Fare
#Cabin
#Embarked

fname=1

def Comm(train, test, result):
        #年龄特征分类
        train['Age']=train['Age'].map(lambda x: 'child' if x<12 else 'youth' 
                             if x<30 else 'adlut' if x<60 else 'old' 
                             if x<75 else 'tooold' if x>=75 else 'null')        
        
        train['SibSp']=train['SibSp'].map(lambda x: 'small' if x<1 else 'middle' 
                                    if x<3 else 'large')
        
        train['Parch']=train['Parch'].map(lambda x: 'small' if x<1 else 'middle' 
                                     if x<4 else 'large')             
            
        train['Fare']=train['Fare'].map(lambda x:np.log(x+1))
        train['Fare']=train['Fare'].map(lambda x: 'poor' if x<2.5 else 'rich')
        
        train['Cabin']=train['Cabin'].map(lambda x:'yes' if type(x)==str else 'no')
               
        #删掉含有缺损值的样本
        train.dropna(axis=0,inplace=True)
            
        
        #删除认为不重要的特征5
        ##将训练数据分成标记和特征两部分        
        features= train.drop(['Survived','PassengerId','Name','Ticket'],axis=1)  
        fname = features.columns.values.tolist()
        
        ##对所有特征实现one-hot 的编码
        features = pd.get_dummies(features)
        
        #处理测试数据
        #对'Age','SibSp'，'Parch'特征进行分段分类
        test['Age']=test['Age'].map(lambda x: 'child' if x<12 else 'youth' if x<30 else 'adlut' if x<60 else 'old' if x<75 else 'tooold' if x>=75 else 'null')
        test['SibSp']=test['SibSp'].map(lambda x: 'small' if x<1 else 'middle' if x<3 else 'large')
        test['Parch']=test['Parch'].map(lambda x: 'small' if x<1 else 'middle' if x<4 else 'large')
        #均值补齐'Fare'特征值并作对数转换和分类
        test.Fare.fillna(test['Fare'].mean(), inplace=True)
        test['Fare']=test['Fare'].map(lambda x:np.log(x+1))
        test['Fare']=test['Fare'].map(lambda x: 'poor' if x<2.5 else 'rich')
        #按'Cabin'是否缺损分类
        test['Cabin']=test['Cabin'].map(lambda x:'yes' if type(x)==str else 'no')
        
        #删除不需要的特征
        test=test.drop(['PassengerId','Name','Ticket'],axis=1)
        
        #进行one-hot编码
        test=pd.get_dummies(test)
              
        #训练数据
        x_train=features
        y_train=train['Survived']
        #测试数据
        x_test=test
        
        return x_train, y_train, x_test, result
        

#数据处理 
#方法1 只使用‘Pclass’,'Sex', 'Fare','Embarked'
def Deal1(train1, test1,result1):
        train1['Fare']=train1['Fare'].map(lambda x:np.log(x+1))
        train1['Fare']=train1['Fare'].map(lambda x: 'poor' if x<2.5 else 'rich')
        train1= train1.drop(['PassengerId','Name','Age','SibSp','Parch',
                                'Ticket', 'Cabin'],axis=1)
        train1.dropna(axis=0,inplace=True)        
        features1= train1.drop(['Survived'],axis=1)
        
        features1 = pd.get_dummies(features1)
        
        x_train1=features1
        y_train1=train1['Survived']
        
        #处理测试数据
        test1.Fare.fillna(test1['Fare'].mean(), inplace=True)
        test1['Fare']=test1['Fare'].map(lambda x:np.log(x+1))
        test1['Fare']=test1['Fare'].map(lambda x: 'poor' if x<2.5 else 'rich')       
        
        #删除不需要的特征
        test1=test1.drop(['PassengerId','Name','Age','SibSp','Parch','Ticket', 'Cabin'],
                         axis=1)        
        #进行one-hot编码
        test1=pd.get_dummies(test1)       
        
        #测试数据
        x_test1=test1
        
        #决策树模型
        dt = DecisionTreeClassifier()
        
        #训练
        dt.fit(x_train1,y_train1)
        
        #测试
        y_test1=dt.predict(x_test1)
        
        #计算准确率
        rate1=accuracy_score(y_test1, result1)
        return rate1
    




#方法2，除了使用‘Name’,'Ticket'
def Deal2(train,test, result):   
        
        [x_train, y_train, x_test, result]=Comm(train,test,result)
        
        dt = DecisionTreeClassifier()
        #DT = DecisionTreeClassifier(criterion='gini',max_depth=10,min_samples_split=5)
        
        #训练
        dt.fit(x_train,y_train)
        
        #测试
        y_test=dt.predict(x_test)
        
        #计算准确率
        rate=accuracy_score(y_test, result)
#        print("方法2的准确率为：",rate)
        return rate
        
        
        
#方法3，ID3
def Deal3(train, test,result):
        [x_train, y_train, x_test, result]=Comm(train,test,result)       
        
        #决策树模型
        dt = DecisionTreeClassifier(criterion="entropy")
#        dt = DecisionTreeClassifier(criterion='gini',max_depth=10,min_samples_split=5)
        
        #训练
        dt.fit(x_train,y_train)
        
        #测试
        y_test=dt.predict(x_test)
        
        #计算准确率
        rate=accuracy_score(y_test, result)
#        print("方法3的准确率为：",rate)
        return rate
        
#方法4，C4.5
def Deal4(train, test,result):
        
        [x_train, y_train, x_test, result]=Comm(train,test,result)       
        
        #决策树模型
        dt = DecisionTreeClassifier(criterion='C4.5')
#        dt = DecisionTreeClassifier(criterion='gini',max_depth=10,min_samples_split=5)
        
        #训练
        dt.fit(x_train,y_train)
        
        #测试
        y_test=dt.predict(x_test)
        
        #计算准确率
        rate=accuracy_score(y_test, result)
#        print("方法4的准确率为：",rate)
        return rate
        
#方法4，CART
def Deal5(train, test,result):
        [x_train, y_train, x_test, result]=Comm(train,test,result)       
        
        #决策树模型
        dt = DecisionTreeClassifier()
#        dt = DecisionTreeClassifier(criterion='gini',max_depth=10,min_samples_split=5)
        
        #训练
        dt.fit(x_train,y_train)
        
        #测试
        y_test=dt.predict(x_test)
        
        #计算准确率
        rate=accuracy_score(y_test, result)
#        print("方法5的准确率为：",rate)
        return rate
        
        
#方法6，deep=3
def Deal6(train, test,result):
        [x_train, y_train, x_test, result]=Comm(train,test,result)       
        
        #决策树模型
        dt = DecisionTreeClassifier(max_depth=3)
        
        #训练
        dt.fit(x_train,y_train)
        
        #测试
        y_test=dt.predict(x_test)
        
        #计算准确率
        rate=accuracy_score(y_test, result)
#        print("方法6的准确率为：",rate)
        return rate

#方法7，deep=5
def Deal7(train, test,result):
        [x_train, y_train, x_test, result]=Comm(train,test,result)       
        
        #决策树模型
        dt = DecisionTreeClassifier(max_depth=5)
        
        #训练
        dt.fit(x_train,y_train)
        
        #测试
        y_test=dt.predict(x_test)
        
        #计算准确率
        rate=accuracy_score(y_test, result)
#        print("方法7的准确率为：",rate)
        return rate
        
        
#方法8，deep=7
def Deal8(train, test,result):
        [x_train, y_train, x_test, result]=Comm(train,test,result)       
        
        #决策树模型
        dt = DecisionTreeClassifier(max_depth=7)
        
        #训练
        dt.fit(x_train,y_train)
        
        #测试
        y_test=dt.predict(x_test)
        
        #计算准确率
        rate=accuracy_score(y_test, result)
#        print("方法8的准确率为：",rate)
        return rate
        
#方法9，deep=10
def Deal9(train, test,result):
        [x_train, y_train, x_test, result]=Comm(train,test,result)       
        
        #决策树模型
        dt = DecisionTreeClassifier(max_depth=10)
        
        #训练
        dt.fit(x_train,y_train)
        
        #测试
        y_test=dt.predict(x_test)
        
        #计算准确率
        rate=accuracy_score(y_test, result)
#        print("方法9的准确率为：",rate)
        return rate
        
#方法9，deep=10
def Deal10(train, test,result):
        [x_train, y_train, x_test, result]=Comm(train,test,result)       
        
        #决策树模型
        dt = DecisionTreeClassifier()
        
        #训练
        dt.fit(x_train,y_train)
        
        #测试
        y_test=dt.predict(x_test)
        
        #计算准确率
        rate=accuracy_score(y_test, result)
#        print("方法10的准确率为：",rate)
        return rate
        

def Func():       
        
        #导入数据
        train = pd.read_csv('train.csv')
        test = pd.read_csv('test.csv')
        result= pd.read_csv('gender_submission.csv')
        result=result['Survived']   
        
              
        #特征值少：
        train0= copy.copy(train)
        test0=copy.copy(test)
        r1 = Deal1(train0,test0,result)
    
        #特征值多：
        train0= copy.copy(train)
        test0=copy.copy(test)
        r2 = Deal2(train0,test0,result)
        
        #ID3
        
        #ID3
        train0= copy.copy(train)
        test0=copy.copy(test)
        r3 = Deal3(train0,test0,result)
        #C4.5
        train0= copy.copy(train)
        test0=copy.copy(test)
#        r4 = Deal4(train0,test0,result)
        #CART
        train0= copy.copy(train)
        test0=copy.copy(test)
        r5 = Deal5(train0,test0,result)
        
        #CART最大深度为3
        train0= copy.copy(train)
        test0=copy.copy(test)
        r6 = Deal6(train0,test0,result)
        #CART最大深度为5
        train0= copy.copy(train)
        test0=copy.copy(test)
        r7 = Deal7(train0,test0,result)
        #CART最大深度为7
        train0= copy.copy(train)
        test0=copy.copy(test)
        r8 = Deal8(train0,test0,result)
        #CART最大深度为10
        train0= copy.copy(train)
        test0=copy.copy(test)
        r9 = Deal9(train0,test0,result)
        #CART不限制
        train0= copy.copy(train)
        test0=copy.copy(test)
        r10 = Deal10(train0,test0,result)  
        
        print(r1,r2,r3,r5,r6,r7,r8,r9,r10)   
        
        [x_train, y_train, x_test, result]=Comm(train,test,result)
        clf_tree = tree.DecisionTreeClassifier()
        clf_tree.fit(x_train, y_train)       
        dot_data = tree.export_graphviz(clf_tree, out_file='./tree.dot', 
                                        feature_names = fname, 
                                        class_names=['1', '2', '3'],
                                        filled=True, rounded=True, special_characters=True)       
        graph = graphviz.Source(dot_data)


if __name__ == '__main__':
	Func()
    








