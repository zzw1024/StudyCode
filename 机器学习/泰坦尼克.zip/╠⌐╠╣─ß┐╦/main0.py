# -*- coding: utf-8 -*-
"""
Created on Sun May 26 10:09:28 2019

@author: 上善若水
"""

import graphviz
import numpy as np
import pandas as pd
import seaborn as sns

#首先引入需要的库和函数
from sklearn import tree
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction import DictVectorizer
from sklearn.metrics import accuracy_score






#导入数据

train = pd.read_csv('train.csv')
test = pd.read_csv('test.csv')
result= pd.read_csv('gender_submission.csv')

#display(train.head(n=1),test.head(n=1))
#查看数据信息
#train.info()
#test.info()


#数据分析
#根据可视图来预测属性是否重要
#sns.countplot(x='Pclass', hue='Survived', data=train)  #***
#sns.countplot(x='Name', hue='Survived', data=train)
#sns.countplot(x='Sex', hue='Survived', data=train)    #***



#年龄数据缺失，使用方法：将缺失数据当做新的属性
#train['Age']=train['Age'].map(lambda x:'yes' if 0<x<100 else 'no')
##作图比较， 发现有年龄记录的存活率高一些
#sns.countplot(x="Age", hue="Survived", data=train)

#作小提琴图
#sns.violinplot(x='Survived',y='Age',data=train)
#从从叠加图中我们可以发现大概年龄在12岁以下的孩子生存率要高一些，
#而年龄12-30岁左右的人死亡率是很高的，30-60岁感觉生存与死亡大体相等，
#60-75岁死亡率又稍稍上升，75岁以上基本存活。
#加上之前没有年龄数值的也可以分为一类，总共分了6类。

#年龄特征分类
train['Age']=train['Age'].map(lambda x: 'child' if x<12 else 'youth' 
                             if x<30 else 'adlut' if x<60 else 'old' 
                             if x<75 else 'tooold' if x>=75 else 'null')


#sns.countplot(x='SibSp', hue='Survived', data=train)
#从图中结果可以看到大部分人这一属性都为0，而为1，2的情况下貌似幸存大概率会增加，
#再大又会下降，所以这个特征可以分成三部分，代码如下：
train['SibSp']=train['SibSp'].map(lambda x: 'small' if x<1 else 'middle' 
                                    if x<3 else 'large')

#sns.countplot(x='Parch', hue='Survived', data=train)
#果然，有父母孩子的比单独旅行的幸存率的确要高，
#我们同样把这个特征分成三部分
train['Parch']=train['Parch'].map(lambda x: 'small' if x<1 else 'middle' 
                                     if x<4 else 'large')

#sns.countplot(x='Ticket', hue='Survived', data=train)  #没用

#sns.violinplot(x='Survived',y='Fare',data=train)
#小提琴图很不均匀  需要先做一下对数转化
#用numpy库里的对数函数对Fare的数值进行对数转换
train['Fare']=train['Fare'].map(lambda x:np.log(x+1))
#作小提琴图：
#sns.violinplot(x='Survived',y='Fare',data=train)
#可以很明显的发现当log(Fare)小于2.5时，死亡率是高于生存率的，
#而大于2.5的生存率是高于死亡率的，因此可以做如下分类：
train['Fare']=train['Fare'].map(lambda x: 'poor' if x<2.5 else 'rich')


#有编号的的为yes,没有的为no
train['Cabin']=train['Cabin'].map(lambda x:'yes' if type(x)==str else 'no')
#作图
#sns.countplot(x="Cabin", hue="Survived", data=train)


#删掉含有缺损值的样本
train.dropna(axis=0,inplace=True)
#查看训练集的信息
#train.info()

#删除认为不重要的特征5
##将训练数据分成标记和特征两部分
labels= train['Survived']
features= train.drop(['Survived','PassengerId','Name','Ticket'],axis=1)
fname = features.columns.values.tolist()


##对所有特征实现one-hot 的编码
#oldfearures=features
features = pd.get_dummies(features)
#特征编码长度个数
#encoded = list(features.columns)
#print ("{} total features after one-hot encoding.".format(len(encoded)))


#处理测试数据
#对'Age','SibSp'，'Parch'特征进行分段分类
test['Age']=test['Age'].map(lambda x: 'child' if x<12 else 'youth' if x<30 else 'adlut' if x<60 else 'old' if x<75 else 'tooold' if x>=75 else 'null')
test['SibSp']=test['SibSp'].map(lambda x: 'small' if x<1 else 'middle' if x<3 else 'large')
test['Parch']=test['Parch'].map(lambda x: 'small' if x<1 else 'middle' if x<4 else 'large')
#均值补齐'Fare'特征值并作对数转换和分类
test.Fare.fillna(test['Fare'].mean(), inplace=True)
test['Fare']=test['Fare'].map(lambda x:np.log(x+1))
test['Fare']=test['Fare'].map(lambda x: 'poor' if x<2.5 else 'rich')
#按'Cabin'是否缺损分类
test['Cabin']=test['Cabin'].map(lambda x:'yes' if type(x)==str else 'no')


#删除不需要的特征
test=test.drop(['PassengerId','Name','Ticket'],axis=1)

#进行one-hot编码
test=pd.get_dummies(test)
#特征编码长度个数
#encoded = list(test.columns)
#print ("{} total features after one-hot encoding.".format(len(encoded)))


#训练数据
x_train=features
y_train=labels  
#测试数据
x_test=test
result=result['Survived']
#决策树模型
dt = DecisionTreeClassifier()
#DT = DecisionTreeClassifier(criterion='gini',max_depth=10,min_samples_split=5)

#训练
dt.fit(x_train,y_train)

#测试
y_test=dt.predict(x_test)

#计算准确率
rate=accuracy_score(y_test, result)
print("准确率为：",rate)

#可视化
clf_tree = tree.DecisionTreeClassifier()
clf_tree.fit(x_train, y_train)
y_tree = clf_tree.predict(x_test)

dot_data = tree.export_graphviz(clf_tree, out_file='./tree.dot', feature_names = fname, 
                                class_names=['1', '2', '3'],
								filled=True, rounded=True, special_characters=True)  
graph = graphviz.Source(dot_data)


