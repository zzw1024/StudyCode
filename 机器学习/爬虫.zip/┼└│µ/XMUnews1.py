# -*- coding:utf-8 -*-
__author = "易超"
# 引入爬虫相关模块
import requests
from lxml import html
import pymysql
pymysql.install_as_MySQLdb()
from bs4 import BeautifulSoup

if __name__ == '__main__':
  #打开数据库连接
  xnews = pymysql.connect(host="localhost", user="root", passwd="342493", db="test", charset='utf8')
  cursor = xnews.cursor()
  #开始爬取主页数据
  for i in range(1,60):
    XMUnews_site = ('http://news.xmu.edu.cn/1552/list{}.htm'.format(i))
    response = requests.get(XMUnews_site)
    response.encoding='UTF-8'
    webdata=response.text
    #  res = html.fromstring(webdata)
    # 对获取到的文本进行解析
    text_analysis = BeautifulSoup(webdata,'lxml') 
    news_titles = text_analysis .select("a")
    for n in news_titles:
        # 提取出标题和链接信息
        title = n.get_text()
        link = n.get("href")
        link = 'http://news.xmu.edu.cn'+ link
        #进入新闻页面
        if len(title) > 6:
          response = requests.get(link)
          response.encoding='UTF-8'
          webdata1=response.text
          #新闻数据解析
          text_analysis1 = BeautifulSoup(webdata1,'lxml') 
          #获取新闻时间、新闻内容
          news_time = text_analysis1.select('.Article_PublishDate')[0].text
          news_content=text_analysis1.select('.Article_Content')[0].text
          #获取浏览次数
          newsviews_list=text_analysis1.select("span")
          for n in newsviews_list:
            if n.get("url") !=None:
              newsviews_link='http://news.xmu.edu.cn'+n.get("url")
              news_views=requests.get(newsviews_link).text
          #增加条件只获取2018年新闻
          if news_time.find('2018') == 0:    
             data = {
                '新闻标题':title,
                '发布时间':news_time,
                '正文链接':link,
                '浏览次数':news_views,
                '正文内容':news_content
                    }
             print(data)
             print('\n')
             #存储在数据库
             sql = '''INSERT INTO XMU(title,timestamp, url, view, content) VALUES ("%s", "%s", "%s", "%s","%s")'''%(title,news_time, link, news_views, news_content)
             print('-------------')
             try:
                 # 执行sql语句
                 cursor.execute(sql)
                 # 提交到数据库执行
                 xnews.commit()
                 print("********************")
             except Exception as e:
                 # Rollback in case there is any error
                 xnews.rollback()
                 print(e)
             
          
          

  
  
  
