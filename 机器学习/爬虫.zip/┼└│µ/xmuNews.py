# -*- coding:utf-8 -*-
__author =  " 周贞文 "

'''
        NewsTitle  # 新闻标题
        NewsContent #新闻内容
        NewsTime   #新闻时间
        NewsView  #新闻浏览量
        NewsURL #新闻链接网址
'''
# 导入相应的包
from bs4 import BeautifulSoup
import re
import time
import pymysql
from urllib import request


def getNewsInfo():
    l = 1  # 新闻列表页数
    NewsModule = []  # 存储每一页的新闻模块（包括有15条新闻记录）
    NewsTitle = []  # 存储每条新闻的标题
    NewsTime = []  # 存储每条新闻的时间
    NewsView = []  # 存储新闻浏览量
    TimeModel = '2018-[0-9]{2}-[0-9]{2}'  # 新闻时间模板，用来判断是否为2018年的新闻
    TimeModel1 = re.compile(TimeModel)
    flag = True
    while (flag):
        url = 'http://news.xmu.edu.cn/1552/list' + str(l) + '.htm'  # 页码网址
        html = request.urlopen(url).read().decode('utf-8')  # 查看网址
        soup = BeautifulSoup(html, 'html.parser')  # 解析网页
        page = soup.find('div', {'id': 'wp_news_w4'})  # 找到新闻模块
        NewsModule = page.findAll('table', {'width': '100%'})  # 找到新闻列表模块
        for table in NewsModule:
            link = table.find('a')  # 新闻信息栏
            Time = table.find('div', {'style': 'white-space:nowrap'}).get_text()  # 得到新闻的时间
            if TimeModel1.match(Time):
                NewsTitle = link['title']  # 新闻标题
                NewsTime = Time  # 存储新闻时间
                try:  # 网页奔溃，跳过
                    NewsURL = 'http://news.xmu.edu.cn' + link['href']  # 具体每条新闻的网址链接
                    response = request.urlopen(NewsURL).read().decode('utf-8', 'ignore')  # 进入新闻网页
                    soup1 = BeautifulSoup(response, 'lxml')

                    try:# 如果网址提取错误，跳过
                        ViewLink = soup1.find('span',{'class':'WP_VisitCount'})  # 找到浏览次数的标签
                        ViewURL = 'http://news.xmu.edu.cn' + ViewLink['url']  # 生成标签网址
                        NewsView = request.urlopen(ViewURL).read().decode('utf-8')
                        NewsView = NewsView[:-2]  #提取浏览次数
                    except:
                        pass
                    NewsContent = soup1.select('.Article_Content')[0].text  #提取新闻内容

                    Newslist = {'新闻标题':NewsTitle,'新闻时间':NewsTime,'浏览次数':NewsView,'新闻地址':NewsURL,'新闻内容':NewsContent }
                    print(Newslist)  #打印新闻内容

                    sql = '''INSERT INTO xmuNews(Title,Timestamp,Views,URL,Content) VALUES ("%s","%s","%s","%s","%s")''' % (NewsTitle, NewsTime, NewsView, NewsURL, NewsContent)
                    try:
                        # 执行sql语句
                        cursor.execute(sql)
                        print('execute')
                        # 提交到数据库执行
                        db.commit()
                    except Exception as e:
                        # Rollback in case there is any error
                        db.rollback()
                        print(e)
                except:
                    pass
            else:
                flag = False #跳出循环
                break
        l = l + 1  #翻页

if __name__ == '__main__':
    # 打开数据库连接
    db = pymysql.connect(host="localhost", user="root", passwd="342493", db="test", charset='utf8')
    print('link ok')
    # 使用cursor()方法获取操作游标
    cursor = db.cursor()
    cursor.execute("DROP TABLE IF EXISTS xmuNews")
    createTab = """CREATE TABLE xmuNews(
        id INT NOT NULL AUTO_INCREMENT PRIMARY KEY, 
        Title VARCHAR(100) NOT NULL, 
        Timestamp VARCHAR(100) NOT NULL,  
        Views VARCHAR(100) NOT NULL,    
        URL VARCHAR(255) NOT NULL, 
        Content LONGTEXT NOT NULL     
    )"""

    cursor.execute(createTab)
    getNewsInfo()
    db.close()

