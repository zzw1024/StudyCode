# 使用神经网络对Iris进行分类
# @author：周贞文
# ====================================
# 导入模块包
import numpy as np
import pandas as pd
import keras as K
from keras.wrappers.scikit_learn import KerasClassifier
from sklearn.model_selection import cross_val_score
from sklearn.model_selection import KFold
from sklearn.metrics import accuracy_score
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder

# 下载数据
Iris_Data = pd.read_csv("./iris.data", header=None)
Iris = Iris_Data.values

#获取特征量
Target = Iris[:, 4]
Encoder = LabelEncoder()
X = Iris[:, 0:4].astype(float)  
Y = Encoder.fit_transform(Target)

#设定随机种子
seed = 7
np.random.seed(seed)
 
# 构建模型函数
def create_model():
	# 模型参数
	optimizer = 'adam'
	init = 'glorot_uniform'
	#构建模型
	model = K.models.Sequential()
	model.add(K.layers.Dense(units=4, activation='relu', input_dim=4, kernel_initializer=init))
	model.add(K.layers.Dense(units=6, activation='relu', kernel_initializer=init))
	model.add(K.layers.Dense(units=3, activation='softmax', kernel_initializer=init))
	#编译模型
	model.compile(loss='categorical_crossentropy', optimizer=optimizer, metrics=['accuracy'])
	return model

def Classify():
	Model = KerasClassifier(build_fn=create_model, epochs=200, batch_size=5, verbose=0)
	X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size=0.4, random_state=0)#训练集和测试集：3:2	

	# 做出预测并计算准确率
	Model.fit(X_train, Y_train)
	Pred = Model.predict(X_test)
	rate = accuracy_score(Pred, Y_test)	
	return rate

if __name__ == '__main__':
	rate = Classify()
	print("*********************")
	print("测试准确率为: %.3f%%" % (rate*100))
	