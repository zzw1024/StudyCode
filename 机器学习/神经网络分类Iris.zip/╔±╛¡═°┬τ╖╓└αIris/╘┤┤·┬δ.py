
from sklearn import datasets
import numpy as np
from keras.models import Sequential
from keras.layers import Dense
from keras.wrappers.scikit_learn import KerasClassifier
from sklearn.model_selection import cross_val_score
from sklearn.model_selection import KFold
 
#导入数据
dataset = datasets.load_iris()
 
x = dataset.data
Y = dataset.target
 
#设定随机种子
seed = 7
np.random.seed(seed)
 
#构建模型函数
def create_model(optimizer = 'adam', init = 'glorot_uniform'):
    #构建模型
    model = Sequential()
    model.add(Dense(units=4, activation='relu', input_dim=4, kernel_initializer=init))
    model.add(Dense(units=6, activation='relu', kernel_initializer=init))
    model.add(Dense(units=3, activation='softmax', kernel_initializer=init))
 
    #编译模型
    model.compile(loss='categorical_crossentropy', optimizer=optimizer, metrics=['accuracy'])
 
    return model
 
model = KerasClassifier(build_fn=create_model, epochs=200, batch_size=5, verbose=0)
kfold = KFold(n_splits=10, shuffle=True, random_state=seed)
results = cross_val_score(model, x,Y, cv=kfold)
print('Accuracy: %.2f%% (%.2f)' % (results.mean()*100, results.std()))
 

这里得到结果，准确率为：

Accuracy: 93.33% (0.10)
 当将代码进行一些小改动：

kfold = KFold(n_splits=10, shuffle=True)
 将 random_state参数去掉，准确率有所提升。

Accuracy: 96.00% (0.06)
--------------------- 
作者：Samuel_0 
来源：CSDN 
原文：https://blog.csdn.net/sun___M/article/details/83584227 
版权声明：本文为博主原创文章，转载请附上博文链接！