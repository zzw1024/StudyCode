# 使用神经网络对Iris进行分类
# @author：周贞文
# ====================================
# 导入模块包
import numpy as np
import pandas as pd
import keras as K  
from keras.wrappers.scikit_learn import KerasClassifier
from keras.utils import np_utils
from sklearn.model_selection import train_test_split, KFold, cross_val_score
from sklearn.preprocessing import LabelEncoder
 
# 下载数据
Iris_Data = pd.read_csv("iris.data", header=None)
Iris = Iris_Data.values

# 获取特征量
Features = Iris[:, 0:4].astype(float)  
Target = Iris[:, 4]
 
# 将花的类名字进行编码为整数
Encoder = LabelEncoder()
Encoded = Encoder.fit_transform(Target)

# 将数据进行one-hot编码
Binary = np_utils.to_categorical(Encoded)
 
# 定义模型
def Define_Model():
    model = K.models.Sequential()
    model.add(K.layers.Dense(output_dim = 10, input_dim = 4, activation = 'relu'))
    model.add(K.layers.Dense(output_dim = 6, input_dim = 4, activation = 'relu'))
    # model.add(K.layers.Dropout(0.2))
    model.add(K.layers.Dense(output_dim = 3, input_dim = 10, activation = 'softmax'))

    # 模型编译
    model.compile(loss = 'categorical_crossentropy', optimizer = 'adam', metrics = ['accuracy'])
    return model


def Classify():
	Estimator = KerasClassifier(build_fn = Define_Model, nb_epoch = 40, batch_size = 256)

	# 将数据分为训练集和测试集，比例为4:1
	X_train, X_test, Y_train, Y_test = train_test_split(Features, Binary, test_size=0.3, random_state=0)
	Estimator.fit(X_train, Y_train)
	 
	# 做出预测
	Pred = Estimator.predict(X_test)

	#初始化标签
	Init_lables = Encoder.inverse_transform(Pred)
	 
	# K-Fold 交叉验证
	seed = 42    #初始化随机数生成器初始化为常量值
	np.random.seed(seed)
	kfold = KFold(n_splits = 10, shuffle = True, random_state = seed)
	results = cross_val_score(Estimator, Features, Binary, cv = kfold)
	return results

if __name__ == '__main__':
	results = Classify()
	print("Baseline: %.2f%% (%.2f%%)" % (results.mean()*100, results.std()*100))