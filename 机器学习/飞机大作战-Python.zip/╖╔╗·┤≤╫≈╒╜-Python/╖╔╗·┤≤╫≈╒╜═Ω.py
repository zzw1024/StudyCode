import pygame
from pygame.locals import *
import time
import random

class BasePlane(object):
	"""创建一个共同的飞机属性"""
	def __init__(self, screen_temp,x,y,image_name,image_name1,image_name2,image_name3,image_name4):
		self.x = x
		self.y = y
		self.screen = screen_temp
		self.image = pygame.image.load(image_name)	#下载飞机图
		self.bullet_list = []	#存储发射出去的子弹对象引用	

		self.image1 = pygame.image.load(image_name1)
		self.image2 = pygame.image.load(image_name2)
		self.image3 = pygame.image.load(image_name3)
		self.image4 = pygame.image.load(image_name4)
		self.hit = False
		self.bomb_list = [] #用来存储爆炸时需要的图片
		self.__crate_images()#调用这个方法向bomb_list中添加图片
		self.image_num = 0#用来记录while True的次数,当次数达到一定值时才显示一张爆炸的图,然后清空,,当这个次数再次达到时,再显示下一个爆炸效果的图片
		self.image_index = 0#用来记录当前要显示的爆炸效果的图片的序号

	def __crate_images(self):
		self.bomb_list.append(self.image1)
		self.bomb_list.append(self.image2)
		self.bomb_list.append(self.image3)
		self.bomb_list.append(self.image4)

	def Display(self):

		if self.hit:
			self.screen.blit(self.bomb_list[self.image_index], (self.x, self.y))
			self.image_num += 1
			if self.image_num == 7:
				self.image_index += 1
				self.image_num = 0
			if self.image_index > 3:
				time.sleep(1)
				exit()
		else:
			self.screen.blit(self.image,(self.x,self.y))   #显示飞机图片

		for bullet in self.bullet_list:
			bullet.Display()
			bullet.Move()
			if bullet.judge():#删除越界的子弹
				self.bullet_list.remove(bullet)     
			
class HeroPlane(BasePlane):
	"""一个战斗机飞机的类"""
	def __init__(self, screen_temp):
		BasePlane.__init__(self,screen_temp,210,700,'./feiji/hero1.png',"./feiji/hero_blowup_n1.png","./feiji/hero_blowup_n2.png","./feiji/hero_blowup_n3.png","./feiji/hero_blowup_n4.png")

	def Move_left(self):	#飞机左移
		self.x -= 8

	def Move_right(self):
		self.x += 8

	def Move_up(self):	#飞机右移
		self.y -= 8

	def Move_down(self):
		self.y += 8

	def Fire(self):		#开枪，将子弹储存
		self.bullet_list.append(HeroBullet(self.screen,self.x,self.y))

	def Bomb(self):
		self.hit = True

class EnemyPlane(BasePlane):
	"""一个敌机的类"""
	def __init__(self, screen_temp):
		BasePlane.__init__(self,screen_temp,0,0,'./feiji/enemy0.png',"./feiji/hero_blowup_n1.png","./feiji/hero_blowup_n2.png","./feiji/hero_blowup_n3.png","./feiji/hero_blowup_n4.png")
		self.direction = 'right' #默认敌机向右移动

	def Move(self):
		if self.direction == 'right':
			self.x += 5
		elif self.direction == 'left':
			self.x -= 5

		if self.x < 0:
			self.direction = 'right'
		elif self.x > 430:
			self.direction = 'left'	

	def Fire(self):		#随机开枪
		random_num = random.randint(1,100)
		if random_num == 33 or random_num == 77:
			self.bullet_list.append(EnemyBullet(self.screen,self.x,self.y))

class BaseBullet(object):
	"""一个共同子弹的类"""
	def __init__(self,screen_temp,x,y,image_name):
		self.x = x 
		self.y = y 
		self.screen = screen_temp
		self.image = pygame.image.load(image_name)	#下载子弹图片

	def Display(self):
		self.screen.blit(self.image,(self.x,self.y))	#显示子弹位子

class HeroBullet(BaseBullet):
	"""一个战斗机子弹的类"""
	def __init__(self,screen_temp,x,y):
		BaseBullet.__init__(self,screen_temp,x+40,y-20,'./feiji/bullet.png')

	def Move(self):
		self.y -= 20
	
	def judge(self):
		if self.y < 0:
			return True
		else:
			return False

class EnemyBullet(BaseBullet):
	"""一个敌机子弹的类"""
	def __init__(self,screen_temp,x,y):
		BaseBullet.__init__(self,screen_temp,x+25,y+40,'./feiji/bullet1.png')

	def Move(self):
		self.y += 10
	
	def judge(self):
		if self.y > 852:
			return True
		else:
			return False


def Key_control(plane_temp):

    #获取事件，比如按键等
    for event in pygame.event.get():

        #判断是否是点击了退出按钮
        if event.type == QUIT:
            print("exit")
            exit()
        #判断是否是按下了键
        elif event.type == KEYDOWN:
            #检测按键是否是a或者left
            if event.key == K_a or event.key == K_LEFT:
                print('left')
                plane_temp.Move_left()
            #检测按键是否是d或者right
            elif event.key == K_d or event.key == K_RIGHT:
                print('right')
                plane_temp.Move_right()
            #检测按键是否是w或者up
            elif event.key == K_w or event.key == K_UP:
                print('up')
                plane_temp.Move_up()
            #检测按键是否是s或者down
            elif event.key == K_d or event.key == K_DOWN:
                print('down')
                plane_temp.Move_down()
            #检测按键是否是空格键
            elif event.key == K_SPACE:
                print('space')
                plane_temp.Fire()
            #检测按键是否为b
            elif event.key == K_b:
                print('b')
                plane_temp.Bomb()



def main():
    #1. 创建窗口
    screen = pygame.display.set_mode((480,852),0,32)

    #2. 创建一个背景图片
    background = pygame.image.load("./feiji/background.png")

    #3. 创建一个飞机对象
    heroplane = HeroPlane(screen)

    enemyplane = EnemyPlane(screen)

    while True:
        screen.blit(background, (0,0))
        heroplane.Display()
        enemyplane.Display()
        enemyplane.Move()
        enemyplane.Fire()
        pygame.display.update()
        Key_control(heroplane)
        time.sleep(0.01)

if __name__ == "__main__":
    main()
