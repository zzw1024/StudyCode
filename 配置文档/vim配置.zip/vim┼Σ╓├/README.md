## .vimrc1的使用

直接将其替换 根目录``` ~/ ```  下的.vimrc，记得将其名字改过来


## .vim的使用

1. 删除原来文件
```
mv ~/.vim ~/.vim.orig
mv ~/.vimrc ~/.vimrc.orig
```

2. 下载并安装

**有网则执行**
```
git clone git://github.com/humiaozuzu/dot-vimrc.git ~/.vim

git clone https://github.com/gmarik/vundle.git ~/.vim/bundle/vundle
```

**无网则执行**
```
将.vim文件移到 ~/ 根目录下
```

3. 建立软连接

```
ln -s ~/.vim/vimrc ~/.vimrc
```

4. 打开vim
然后输入并回车

```
:BundleInstall
```

5. 最后
```
将 .vimrc2 更改名字为 vimrc 并替换到 ~/.vim/vimrc
```


